Optional bundled Yekan font location.
To bundle Yekan with the APK, place a properly licensed Yekan TTF file at:
app/src/main/assets/fonts/yekan.ttf
The app also supports importing a TTF/OTF at runtime in Settings.
