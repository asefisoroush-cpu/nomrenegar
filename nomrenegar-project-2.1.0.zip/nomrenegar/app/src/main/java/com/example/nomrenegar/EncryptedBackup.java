package com.example.nomrenegar;

import android.content.Context;
import android.util.Base64;
import org.json.JSONObject;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import java.util.Iterator;

public final class EncryptedBackup {
    private static final byte[] MAGIC = new byte[]{'N','R','B','K','1'};
    private EncryptedBackup() {}
    private static SecretKeySpec key(char[] password, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password, salt, 150000, 256);
        byte[] raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        spec.clearPassword();
        return new SecretKeySpec(raw, "AES");
    }
    public static void write(Context context, OutputStream out, char[] password) throws Exception {
        JSONObject data = ScoreStore.exportJson(context);
        byte[] salt = new byte[16], iv = new byte[12];
        SecureRandom random = new SecureRandom(); random.nextBytes(salt); random.nextBytes(iv);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key(password, salt), new GCMParameterSpec(128, iv));
        byte[] encrypted = cipher.doFinal(data.toString().getBytes("UTF-8"));
        out.write(MAGIC); out.write(salt); out.write(iv); out.write(encrypted); out.flush();
    }
    public static void read(Context context, InputStream in, char[] password) throws Exception {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] chunk = new byte[4096]; int n;
        while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n);
        byte[] all = buffer.toByteArray();
        if (all.length < 5+16+12+16) throw new IllegalArgumentException("فایل پشتیبان معتبر نیست.");
        for(int i=0;i<MAGIC.length;i++) if(all[i]!=MAGIC[i]) throw new IllegalArgumentException("قالب فایل پشتیبان شناخته نشد.");
        byte[] salt = java.util.Arrays.copyOfRange(all,5,21);
        byte[] iv = java.util.Arrays.copyOfRange(all,21,33);
        byte[] encrypted = java.util.Arrays.copyOfRange(all,33,all.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key(password,salt), new GCMParameterSpec(128,iv));
        JSONObject data = new JSONObject(new String(cipher.doFinal(encrypted), "UTF-8"));
        ScoreStore.importJson(context, data);
    }
}
