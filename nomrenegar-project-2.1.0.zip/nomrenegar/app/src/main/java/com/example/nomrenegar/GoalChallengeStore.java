package com.example.nomrenegar;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Storage and end-of-day scoring for the optional Goal Challenge. */
public final class GoalChallengeStore {
    private static final String PREFS = "goal_challenge_v1";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_PROMPTED = "prompted";
    private static final String KEY_LAST_EVALUATED = "last_evaluated";
    private static final String DAILY_PREFIX = "daily_";
    private static final String DONE_PREFIX = "done_";
    private static final String FINAL_PREFIX = "finalized_";
    private static final String RECURRING = "recurring_goals";
    private static final String RESULT_DATE = "last_result_date";
    private static final String RESULT_SCORE = "last_result_score";
    private static final String RESULT_PENDING = "result_pending";

    private GoalChallengeStore() {}
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    public static boolean isEnabled(Context c) { return prefs(c).getBoolean(KEY_ENABLED, false); }
    public static boolean wasPrompted(Context c) { return prefs(c).getBoolean(KEY_PROMPTED, false); }
    public static void markPrompted(Context c) { prefs(c).edit().putBoolean(KEY_PROMPTED, true).apply(); }
    public static void setEnabled(Context c, boolean enabled) {
        SharedPreferences p=prefs(c);
        SharedPreferences.Editor e=p.edit().putBoolean(KEY_ENABLED, enabled).putBoolean(KEY_PROMPTED, true);
        if (enabled && !p.contains(KEY_LAST_EVALUATED)) e.putString(KEY_LAST_EVALUATED, LocalDate.now().minusDays(1).toString());
        if (enabled) e.putString(KEY_LAST_EVALUATED, LocalDate.now().minusDays(1).toString());
        e.apply();
        if (enabled) GoalChallengeWorker.scheduleNext(c); else GoalChallengeWorker.cancel(c);
    }

    public static List<Goal> dailyGoals(Context c, LocalDate date) {
        List<Goal> out=new ArrayList<>(); JSONArray a;
        try { a=new JSONArray(prefs(c).getString(DAILY_PREFIX+date, "[]")); }
        catch(Exception e) { return out; }
        for(int i=0;i<a.length();i++) {
            JSONObject o=a.optJSONObject(i); if(o==null) continue;
            out.add(new Goal(o.optString("id"),o.optString("name"),o.optInt("weight",10),o.optBoolean("done",false),false,0,true));
        }
        return out;
    }

    public static List<Goal> recurringDefinitions(Context c) {
        List<Goal> out=new ArrayList<>(); JSONArray a;
        try { a=new JSONArray(prefs(c).getString(RECURRING, "[]")); }
        catch(Exception e) { return out; }
        for(int i=0;i<a.length();i++) {
            JSONObject o=a.optJSONObject(i); if(o==null) continue;
            out.add(new Goal(o.optString("id"),o.optString("name"),o.optInt("weight",10),false,true,o.optInt("days",0),false));
        }
        return out;
    }

    public static List<Goal> goalsForDate(Context c, LocalDate date) {
        List<Goal> out=new ArrayList<>(dailyGoals(c,date));
        for(Goal g:recurringDefinitions(c)) {
            int bit=1 << (date.getDayOfWeek().getValue()-1);
            if((g.daysMask & bit)!=0) {
                boolean done=prefs(c).getBoolean(doneKey(date,g.id),false);
                out.add(new Goal(g.id,g.name,g.weightTenths,done,true,g.daysMask,true));
            }
        }
        return out;
    }

    public static List<Goal> suggestionsFromPreviousDay(Context c, LocalDate date) {
        return dailyGoals(c,date.minusDays(1));
    }

    public static void addDailyGoal(Context c, LocalDate date, String name, int weightTenths) {
        List<Goal> goals=dailyGoals(c,date);
        goals.add(new Goal(UUID.randomUUID().toString(),clean(name),clampWeight(weightTenths),false,false,0,true));
        saveDaily(c,date,goals);
    }

    public static void addRecurringGoal(Context c, String name, int weightTenths, int daysMask) {
        List<Goal> goals=recurringDefinitions(c);
        goals.add(new Goal(UUID.randomUUID().toString(),clean(name),clampWeight(weightTenths),false,true,daysMask,false));
        saveRecurring(c,goals);
    }

    public static void addSuggestion(Context c, LocalDate date, Goal suggestion) {
        for(Goal current:dailyGoals(c,date)) if(current.name.equalsIgnoreCase(suggestion.name)) return;
        addDailyGoal(c,date,suggestion.name,suggestion.weightTenths);
    }

    public static void toggleDaily(Context c, LocalDate date, String id, boolean done) {
        List<Goal> goals=dailyGoals(c,date);
        for(Goal g:goals) if(g.id.equals(id)) g.done=done;
        saveDaily(c,date,goals);
    }

    public static void toggleRecurring(Context c, LocalDate date, String id, boolean done) {
        prefs(c).edit().putBoolean(doneKey(date,id),done).apply();
    }

    public static void deleteDaily(Context c, LocalDate date, String id) {
        List<Goal> goals=dailyGoals(c,date); goals.removeIf(g->g.id.equals(id)); saveDaily(c,date,goals);
    }

    public static void deleteRecurring(Context c, String id) {
        List<Goal> goals=recurringDefinitions(c); goals.removeIf(g->g.id.equals(id)); saveRecurring(c,goals);
    }

    public static boolean isFinalized(Context c, LocalDate date) { return prefs(c).getBoolean(FINAL_PREFIX+date,false); }

    /** Evaluates every closed day not yet processed. Base 5 plus/minus each goal's assigned weight. */
    public static List<Evaluation> evaluateClosedDays(Context c, LocalDate today) {
        List<Evaluation> results=new ArrayList<>();
        SharedPreferences p=prefs(c);
        if(!isEnabled(c)) return results;
        LocalDate last;
        try { last=LocalDate.parse(p.getString(KEY_LAST_EVALUATED,today.minusDays(1).toString())); }
        catch(Exception e) { last=today.minusDays(1); }
        LocalDate lastClosed=today.minusDays(1);
        while(last.isBefore(lastClosed)) {
            LocalDate date=last.plusDays(1);
            if(!isFinalized(c,date)) {
                List<Goal> goals=goalsForDate(c,date);
                if(!goals.isEmpty()) {
                    int score=50;
                    int positive=0,negative=0;
                    for(Goal goal:goals) {
                        if(goal.done){score+=goal.weightTenths;positive+=goal.weightTenths;}
                        else {score-=goal.weightTenths;negative+=goal.weightTenths;}
                    }
                    score=Math.max(0,Math.min(100,score));
                    ScoreStore.saveScore(c,date,score);
                    Evaluation evaluation=new Evaluation(date,score,positive,negative,goals.size());
                    results.add(evaluation);
                    p.edit().putBoolean(RESULT_PENDING,true).putString(RESULT_DATE,date.toString()).putInt(RESULT_SCORE,score).apply();
                }
                p.edit().putBoolean(FINAL_PREFIX+date,true).apply();
            }
            last=date;
            p.edit().putString(KEY_LAST_EVALUATED,last.toString()).apply();
        }
        return results;
    }

    public static Evaluation consumePendingResult(Context c) {
        SharedPreferences p=prefs(c);
        if(!p.getBoolean(RESULT_PENDING,false)) return null;
        try {
            Evaluation result=new Evaluation(LocalDate.parse(p.getString(RESULT_DATE,LocalDate.now().toString())),p.getInt(RESULT_SCORE,50),0,0,0);
            p.edit().putBoolean(RESULT_PENDING,false).apply();
            return result;
        } catch(Exception e) { p.edit().putBoolean(RESULT_PENDING,false).apply(); return null; }
    }

    public static String daysLabel(Context c,int mask) {
        String[] fa={"دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه","یکشنبه"};
        String[] en={"Mon","Tue","Wed","Thu","Fri","Sat","Sun"};
        StringBuilder b=new StringBuilder();
        for(int i=0;i<7;i++) if((mask&(1<<i))!=0){if(b.length()>0)b.append(AppSettings.isEnglish(c)?", ":"، ");b.append(AppSettings.isEnglish(c)?en[i]:fa[i]);}
        return b.toString();
    }

    public static JSONObject exportJson(Context c) throws JSONException {
        JSONObject out=new JSONObject(); SharedPreferences p=prefs(c);
        out.put("enabled",p.getBoolean(KEY_ENABLED,false));
        out.put("prompted",p.getBoolean(KEY_PROMPTED,false));
        out.put("lastEvaluated",p.getString(KEY_LAST_EVALUATED,""));
        out.put("recurring",new JSONArray(p.getString(RECURRING,"[]")));
        JSONObject data=new JSONObject(), done=new JSONObject(), finalized=new JSONObject();
        for(Map.Entry<String,?> e:p.getAll().entrySet()) {
            String k=e.getKey();
            if(k.startsWith(DAILY_PREFIX)&&e.getValue() instanceof String) data.put(k.substring(DAILY_PREFIX.length()),new JSONArray((String)e.getValue()));
            else if(k.startsWith(DONE_PREFIX)&&e.getValue() instanceof Boolean) done.put(k.substring(DONE_PREFIX.length()),e.getValue());
            else if(k.startsWith(FINAL_PREFIX)&&e.getValue() instanceof Boolean) finalized.put(k.substring(FINAL_PREFIX.length()),e.getValue());
        }
        out.put("daily",data);out.put("done",done);out.put("finalized",finalized);
        return out;
    }

    public static void importJson(Context c, JSONObject data) throws JSONException {
        if(data==null)return;
        SharedPreferences.Editor e=prefs(c).edit();
        e.putBoolean(KEY_ENABLED,data.optBoolean("enabled",false));e.putBoolean(KEY_PROMPTED,data.optBoolean("prompted",true));
        String last=data.optString("lastEvaluated","");if(!last.isEmpty())e.putString(KEY_LAST_EVALUATED,last);
        e.putString(RECURRING,data.optJSONArray("recurring")==null?"[]":data.optJSONArray("recurring").toString());
        JSONObject daily=data.optJSONObject("daily");if(daily!=null){java.util.Iterator<String> it=daily.keys();while(it.hasNext()){String date=it.next();try{LocalDate.parse(date);e.putString(DAILY_PREFIX+date,daily.getJSONArray(date).toString());}catch(Exception ignored){}}}
        JSONObject done=data.optJSONObject("done");if(done!=null){java.util.Iterator<String> it=done.keys();while(it.hasNext()){String key=it.next();e.putBoolean(DONE_PREFIX+key,done.optBoolean(key,false));}}
        JSONObject finalized=data.optJSONObject("finalized");if(finalized!=null){java.util.Iterator<String> it=finalized.keys();while(it.hasNext()){String date=it.next();e.putBoolean(FINAL_PREFIX+date,finalized.optBoolean(date,false));}}
        e.apply();
        if(isEnabled(c))GoalChallengeWorker.scheduleNext(c);else GoalChallengeWorker.cancel(c);
    }

    private static String doneKey(LocalDate date,String id){return DONE_PREFIX+date+"_"+id;}
    private static int clampWeight(int v){return Math.max(1,Math.min(50,v));}
    private static String clean(String s){return s==null?"":s.trim();}
    private static void saveDaily(Context c,LocalDate date,List<Goal> goals){JSONArray a=new JSONArray();for(Goal g:goals){JSONObject o=new JSONObject();try{o.put("id",g.id);o.put("name",g.name);o.put("weight",g.weightTenths);o.put("done",g.done);a.put(o);}catch(JSONException ignored){}}prefs(c).edit().putString(DAILY_PREFIX+date,a.toString()).apply();}
    private static void saveRecurring(Context c,List<Goal> goals){JSONArray a=new JSONArray();for(Goal g:goals){JSONObject o=new JSONObject();try{o.put("id",g.id);o.put("name",g.name);o.put("weight",g.weightTenths);o.put("days",g.daysMask);a.put(o);}catch(JSONException ignored){}}prefs(c).edit().putString(RECURRING,a.toString()).apply();}

    public static final class Goal {
        public final String id,name; public final int weightTenths; public boolean done; public final boolean recurring; public final int daysMask; public final boolean activeToday;
        Goal(String id,String name,int weight,boolean done,boolean recurring,int daysMask,boolean active){this.id=id;this.name=name;this.weightTenths=clampWeight(weight);this.done=done;this.recurring=recurring;this.daysMask=daysMask;this.activeToday=active;}
        public double weight(){return weightTenths/10.0;}
    }
    public static final class Evaluation {
        public final LocalDate date; public final int scoreTenths,positiveTenths,negativeTenths,goalCount;
        Evaluation(LocalDate date,int score,int positive,int negative,int count){this.date=date;scoreTenths=score;positiveTenths=positive;negativeTenths=negative;goalCount=count;}
    }
}
