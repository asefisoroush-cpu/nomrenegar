package com.example.nomrenegar;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.time.temporal.TemporalAdjusters;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private int BG=Color.rgb(239,245,253), WHITE=Color.WHITE, INK=Color.rgb(15,39,75), MUTED=Color.rgb(94,119,153), PRIMARY=Color.rgb(12,77,159), PALE=Color.rgb(222,236,255), TEAL=Color.rgb(0,150,145), ORANGE=Color.rgb(243,151,43);
    private static final int CREATE_BACKUP=8101, OPEN_BACKUP=8102, IMPORT_FONT=8301;
    private boolean resultDialogVisible=false;
    private String currentPage="home";
    private char[] pendingBackupPassword;
    private Uri exportedUri;
    private YearMonth calendarMonth=YearMonth.now();
    private int rangeMode=0, chartIndex=0;
    private TextView recentChoice, calendarChoice, chartTitle, averageValue, chartCount, pageIndicator;
    private ScoreChartView chartView;
    private LinearLayout chartCard;

    @Override protected void onCreate(Bundle state){super.onCreate(state);applyPalette();ReminderScheduler.createNotificationChannel(this);ReminderScheduler.schedule(this);GoalChallengeStore.evaluateClosedDays(this,LocalDate.now());GoalChallengeWorker.scheduleNext(this);showHome();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7001);getWindow().getDecorView().post(()->{maybeShowChallengeIntro();showPendingChallengeResult();});}
    @Override protected void onResume(){super.onResume();ReminderScheduler.schedule(this);GoalChallengeStore.evaluateClosedDays(this,LocalDate.now());GoalChallengeWorker.scheduleNext(this);if(!isFinishing())getWindow().getDecorView().post(this::showPendingChallengeResult);}
    @Override public void onBackPressed(){if(!"home".equals(currentPage))showHome();else super.onBackPressed();}
    private void applyPalette(){AppSettings.Palette p=AppSettings.palette(this);BG=p.bg;WHITE=p.white;INK=p.ink;MUTED=p.muted;PRIMARY=p.primary;PALE=p.pale;TEAL=p.accent;getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);}
    private String tr(String s){return AppSettings.tr(this,s);}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable rounded(int color,float radius){GradientDrawable s=new GradientDrawable();s.setColor(color);s.setCornerRadius(dp(radius));return s;}
    private GradientDrawable gradient(int c1,int c2,float radius){GradientDrawable s=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{c1,c2});s.setCornerRadius(dp(radius));return s;}
    private TextView text(String value,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(tr(value));t.setTextSize(size);t.setTextColor(color);boolean en=AppSettings.isEnglish(this);t.setGravity((en?Gravity.LEFT:Gravity.RIGHT)|Gravity.CENTER_VERTICAL);t.setTextDirection(en?View.TEXT_DIRECTION_LTR:View.TEXT_DIRECTION_RTL);t.setTypeface(AppSettings.typeface(this),bold?Typeface.BOLD:Typeface.NORMAL);return t;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(AppSettings.isEnglish(this)?View.LAYOUT_DIRECTION_LTR:View.LAYOUT_DIRECTION_RTL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setLayoutDirection(AppSettings.isEnglish(this)?View.LAYOUT_DIRECTION_LTR:View.LAYOUT_DIRECTION_RTL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private Button button(String label){Button b=new Button(this);b.setText(tr(label));b.setTextSize(14);b.setTextColor(WHITE);b.setAllCaps(false);b.setTypeface(AppSettings.typeface(this),Typeface.BOLD);b.setBackground(rounded(PRIMARY,15));b.setMinHeight(dp(44));return b;}
    private Button lightButton(String label){Button b=button(label);b.setTextColor(PRIMARY);b.setBackground(rounded(PALE,15));return b;}

    private void showHome(){
        currentPage="home";
        LinearLayout root=vertical();root.setBackgroundColor(BG);
        LinearLayout top=horizontal();top.setPadding(dp(18),dp(8),dp(18),dp(8));
        TextView menu=text("⋮",31,PRIMARY,true);menu.setGravity(Gravity.CENTER);menu.setBackground(rounded(WHITE,14));menu.setElevation(dp(1));menu.setOnClickListener(v->showMenu());top.addView(menu,new LinearLayout.LayoutParams(dp(48),dp(44)));
        View spacer=new View(this);top.addView(spacer,new LinearLayout.LayoutParams(0,1,1));
        LinearLayout titles=vertical();TextView h=text("نمره‌نگار",20,INK,true);TextView sub=text("ثبت روزانه و مرور روند",11,MUTED,false);titles.addView(h);titles.addView(sub);titles.setGravity(Gravity.CENTER_VERTICAL|(AppSettings.isEnglish(this)?Gravity.LEFT:Gravity.RIGHT));top.addView(titles);root.addView(top,new LinearLayout.LayoutParams(-1,dp(62)));

        LinearLayout controls=horizontal();controls.setPadding(dp(18),dp(4),dp(18),dp(8));
        recentChoice=choiceButton("اخیر",rangeMode==0);calendarChoice=choiceButton("تقویمی",rangeMode==1);
        controls.addView(recentChoice,new LinearLayout.LayoutParams(0,dp(42),1));View gap=new View(this);controls.addView(gap,new LinearLayout.LayoutParams(dp(8),1));controls.addView(calendarChoice,new LinearLayout.LayoutParams(0,dp(42),1));
        recentChoice.setOnClickListener(v->{rangeMode=0;chartIndex=0;refreshHomeChart();});calendarChoice.setOnClickListener(v->{rangeMode=1;chartIndex=0;refreshHomeChart();});root.addView(controls);

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(false);LinearLayout body=vertical();body.setPadding(dp(18),dp(2),dp(18),dp(10));scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        chartCard=vertical();chartCard.setPadding(dp(15),dp(10),dp(15),dp(10));chartCard.setBackground(rounded(WHITE,22));chartCard.setElevation(dp(2));
        LinearLayout heading=horizontal();chartTitle=text("",16,INK,true);heading.addView(chartTitle,new LinearLayout.LayoutParams(0,dp(34),1));pageIndicator=text("۱ از ۳",11,MUTED,false);pageIndicator.setGravity(Gravity.CENTER);heading.addView(pageIndicator,new LinearLayout.LayoutParams(dp(62),dp(30)));chartCard.addView(heading);
        chartView=new ScoreChartView(this);AppSettings.Palette chartPalette=AppSettings.palette(this);chartView.setPalette(chartPalette.muted,chartPalette.primary,chartPalette.accent,Color.rgb(225,234,247));chartCard.addView(chartView,new LinearLayout.LayoutParams(-1,dp(230)));
        LinearLayout nav=horizontal();Button prev=lightButton("‹ قبلی"),next=lightButton("بعدی ›");nav.addView(prev,new LinearLayout.LayoutParams(0,dp(42),1));View navGap=new View(this);nav.addView(navGap,new LinearLayout.LayoutParams(dp(10),1));nav.addView(next,new LinearLayout.LayoutParams(0,dp(42),1));chartCard.addView(nav);prev.setOnClickListener(v->moveChart(-1));next.setOnClickListener(v->moveChart(1));
        final float[] touchX={0};chartView.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){touchX[0]=e.getX();return true;}if(e.getAction()==MotionEvent.ACTION_UP){float delta=e.getX()-touchX[0];if(Math.abs(delta)>dp(45))moveChart(delta>0?-1:1);return true;}return true;});
        body.addView(chartCard,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout avg=horizontal();avg.setPadding(dp(5),dp(6),dp(5),dp(2));TextView avgLabel=text("میانگین این بازه",13,MUTED,false);avg.addView(avgLabel,new LinearLayout.LayoutParams(0,dp(39),1));averageValue=text("—",23,TEAL,true);averageValue.setGravity(Gravity.CENTER);avg.addView(averageValue,new LinearLayout.LayoutParams(dp(100),dp(39)));body.addView(avg);
        chartCount=text("",11,MUTED,false);chartCount.setGravity(Gravity.CENTER);body.addView(chartCount,new LinearLayout.LayoutParams(-1,dp(25)));
        TextView note=text("فقط روزهای ثبت‌شده در نمودار و میانگین حساب می‌شوند.",11,MUTED,false);note.setGravity(Gravity.CENTER);body.addView(note,new LinearLayout.LayoutParams(-1,dp(28)));

        FrameLayout circleArea=new FrameLayout(this);circleArea.setClipChildren(false);circleArea.setClipToPadding(false);
        int diameter=Math.min(getResources().getDisplayMetrics().widthPixels-dp(36),dp(390));
        circleArea.setLayoutParams(new LinearLayout.LayoutParams(-1,diameter));
        View circle=new View(this);circle.setBackground(gradient(Color.rgb(12,50,107),PRIMARY,diameter/2f));FrameLayout.LayoutParams circleLp=new FrameLayout.LayoutParams(diameter,diameter,Gravity.TOP|Gravity.CENTER_HORIZONTAL);circle.setElevation(dp(1));circleArea.addView(circle,circleLp);
        TextView register=text("ثبت امروز",16,WHITE,true);register.setGravity(Gravity.CENTER);register.setBackground(rounded(TEAL,24));register.setElevation(dp(4));FrameLayout.LayoutParams registerLp=new FrameLayout.LayoutParams(dp(220),dp(54),Gravity.TOP|Gravity.CENTER_HORIZONTAL);registerLp.topMargin=dp(25);circleArea.addView(register,registerLp);register.setOnClickListener(v->showScoreDialog());
        TextView todaysub=text("نمرهٔ امروز هنوز ثبت نشده",12,Color.rgb(221,236,252),false);todaysub.setGravity(Gravity.CENTER);FrameLayout.LayoutParams todayLp=new FrameLayout.LayoutParams(-1,dp(26),Gravity.TOP);todayLp.topMargin=dp(83);circleArea.addView(todaysub,todayLp);
        body.addView(circleArea,new LinearLayout.LayoutParams(-1,diameter));circleArea.setAlpha(.75f);circleArea.post(()->circleArea.animate().alpha(1f).setDuration(650).start());
        Integer saved=ScoreStore.getTenths(this,LocalDate.now());if(saved!=null){register.setText(AppSettings.formatScore(this,saved/10.0));todaysub.setText(tr("نمرهٔ امروز ثبت شده؛ برای ویرایش بزن."));}
        setContentView(root);refreshHomeChart();
    }

    private TextView choiceButton(String label,boolean selected){TextView t=text(label,15,selected?WHITE:PRIMARY,true);t.setGravity(Gravity.CENTER);t.setBackground(rounded(selected?PRIMARY:WHITE,14));t.setElevation(selected?dp(1):0);return t;}
    private void refreshHomeChart(){if(chartView==null||isFinishing())return;recentChoice.setBackground(rounded(rangeMode==0?PRIMARY:WHITE,14));recentChoice.setTextColor(rangeMode==0?WHITE:PRIMARY);calendarChoice.setBackground(rounded(rangeMode==1?PRIMARY:WHITE,14));calendarChoice.setTextColor(rangeMode==1?WHITE:PRIMARY);
        LocalDate today=LocalDate.now(),start,end;String title;int total;
        if(rangeMode==0){int[] sizes={7,30,365};String[] titles={"۷ روز اخیر","۳۰ روز اخیر","۳۶۵ روز اخیر"};total=sizes[chartIndex];start=today.minusDays(total-1L);end=today;title=titles[chartIndex];}
        else {if(chartIndex==0){start=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));end=start.plusDays(6);title="هفتهٔ جاری میلادی";}else if(chartIndex==1){YearMonth m=YearMonth.from(today);start=m.atDay(1);end=m.atEndOfMonth();title="ماه جاری میلادی";}else{start=LocalDate.of(today.getYear(),1,1);end=LocalDate.of(today.getYear(),12,31);title="سال جاری میلادی";}total=(int)(java.time.temporal.ChronoUnit.DAYS.between(start,end)+1);}
        chartTitle.setText(tr(title));pageIndicator.setText(AppSettings.isEnglish(this)?(chartIndex+1)+" of 3":AppSettings.digits(this,(chartIndex+1)+" از ۳"));Map<LocalDate,Integer> all=ScoreStore.getAllScores(this);chartView.setScores(all,start,end);ScoreStore.Average av=ScoreStore.averageForRange(this,start,end,total);averageValue.setText(av.value==null?"—":AppSettings.formatScore(this,av.value));chartCount.setText(av.recordedDays==0?tr("هیچ نمره‌ای در این بازه ثبت نشده"):(AppSettings.isEnglish(this)?"Based on "+av.recordedDays+" recorded days out of "+total+" days":"بر پایهٔ "+ScoreStore.toPersianDigits(String.valueOf(av.recordedDays))+" روز ثبت‌شده از "+ScoreStore.toPersianDigits(String.valueOf(total))+" روز"));}
    private void moveChart(int amount){chartIndex=(chartIndex+amount+3)%3;refreshHomeChart();}

    private void showScoreDialog(){Integer saved=ScoreStore.getTenths(this,LocalDate.now());NumberPicker picker=new NumberPicker(this);picker.setMinValue(0);picker.setMaxValue(100);String[] vals=new String[101];for(int i=0;i<=100;i++)vals[i]=AppSettings.formatScore(this,i/10.0);picker.setDisplayedValues(vals);picker.setWrapSelectorWheel(false);picker.setValue(saved==null?50:saved);LinearLayout panel=vertical();panel.setPadding(dp(16),dp(8),dp(16),0);TextView date=text((AppSettings.isEnglish(this)?"Gregorian date: ":"تاریخ میلادی: ")+LocalDate.now(),13,MUTED,false);date.setGravity(Gravity.CENTER);panel.addView(date);panel.addView(picker,new LinearLayout.LayoutParams(-1,dp(190)));
        new AlertDialog.Builder(this).setTitle(tr(saved==null?"ثبت نمرهٔ امروز":"ویرایش نمرهٔ امروز")).setView(panel).setNegativeButton(tr("لغو"),null).setPositiveButton(tr("ذخیره"),(d,w)->{ScoreStore.saveScore(this,LocalDate.now(),picker.getValue());showHome();Toast.makeText(this,tr("نمره ذخیره شد."),Toast.LENGTH_SHORT).show();}).show();}

    private void showMenu(){
        final Dialog dialog=new Dialog(this);LinearLayout panel=vertical();panel.setPadding(dp(20),dp(18),dp(20),dp(14));panel.setBackground(rounded(Color.rgb(247,250,255),24));TextView heading=text("منو",20,INK,true);panel.addView(heading,new LinearLayout.LayoutParams(-1,dp(42)));
        addMenuItem(panel,"چالش هدف‌گذاری","مدیریت اهداف روزانه و مستمر",()->{dialog.dismiss();openGoalChallenge();});addMenuItem(panel,"تنظیمات","ظاهر، زبان و یادآور روزانه",()->{dialog.dismiss();showSettingsPage();});addMenuItem(panel,"تقویم","نمره‌های روزانه در تقویم میلادی",()->{dialog.dismiss();showCalendarPage();});addMenuItem(panel,"پشتیبان‌گیری","ساخت و بازیابی فایل پشتیبان",()->{dialog.dismiss();showBackupPage();});
        TextView close=text("بستن",14,PRIMARY,true);close.setGravity(Gravity.CENTER);close.setBackground(rounded(PALE,12));panel.addView(close,new LinearLayout.LayoutParams(-1,dp(42)));close.setOnClickListener(v->dialog.dismiss());
        dialog.setContentView(panel);Window win=dialog.getWindow();if(win!=null){win.setBackgroundDrawableResource(android.R.color.transparent);WindowManager.LayoutParams lp=new WindowManager.LayoutParams();lp.copyFrom(win.getAttributes());lp.width=-1;lp.height=(int)(getResources().getDisplayMetrics().heightPixels*.68f);lp.gravity=Gravity.TOP;lp.dimAmount=.22f;win.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);win.setAttributes(lp);}dialog.show();if(win!=null){win.setLayout(-1,(int)(getResources().getDisplayMetrics().heightPixels*.68f));win.setGravity(Gravity.TOP);}
    }
    private void addMenuItem(LinearLayout panel,String title,String detail,Runnable run){LinearLayout item=vertical();item.setPadding(dp(15),dp(9),dp(15),dp(8));item.setBackground(rounded(WHITE,15));item.setElevation(dp(1));item.addView(text(title,16,INK,true));item.addView(text(detail,11,MUTED,false));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(68));lp.topMargin=dp(7);panel.addView(item,lp);item.setOnClickListener(v->run.run());}

    private LinearLayout makeSubPage(String title,String subtitle){currentPage="subpage";LinearLayout root=vertical();root.setBackgroundColor(BG);LinearLayout top=horizontal();top.setPadding(dp(16),dp(8),dp(16),dp(8));TextView back=text("‹",32,PRIMARY,true);back.setGravity(Gravity.CENTER);back.setBackground(rounded(WHITE,14));back.setOnClickListener(v->showHome());top.addView(back,new LinearLayout.LayoutParams(dp(44),dp(42)));LinearLayout hs=vertical();hs.setPadding(dp(12),0,0,0);hs.addView(text(title,21,INK,true));hs.addView(text(subtitle,11,MUTED,false));top.addView(hs,new LinearLayout.LayoutParams(0,dp(50),1));TextView menu=text("⋮",28,PRIMARY,true);menu.setGravity(Gravity.CENTER);menu.setBackground(rounded(WHITE,14));menu.setOnClickListener(v->showMenu());top.addView(menu,new LinearLayout.LayoutParams(dp(44),dp(42)));root.addView(top,new LinearLayout.LayoutParams(-1,dp(62)));ScrollView scroll=new ScrollView(this);LinearLayout body=vertical();body.setPadding(dp(18),dp(10),dp(18),dp(22));scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);return body;}
    private View actionCard(String title,String sub,String symbol,Runnable action){LinearLayout card=vertical();card.setPadding(dp(16),dp(13),dp(16),dp(12));card.setBackground(rounded(WHITE,19));card.setElevation(dp(1));TextView icon=text(symbol,17,PRIMARY,true);icon.setGravity(Gravity.CENTER);icon.setBackground(rounded(PALE,30));card.addView(icon,new LinearLayout.LayoutParams(dp(34),dp(34)));TextView t=text(title,16,INK,true);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(-1,dp(34));tlp.topMargin=dp(4);card.addView(t,tlp);card.addView(text(sub,12,MUTED,false));card.setOnClickListener(v->action.run());return card;}

    private void showSettingsPage(){
        LinearLayout body=makeSubPage("تنظیمات","ظاهر، زبان و یادآور روزانه");
        LinearLayout challenge=vertical();challenge.setPadding(dp(16),dp(14),dp(16),dp(14));challenge.setBackground(rounded(WHITE,19));
        challenge.addView(text("چالش هدف‌گذاری",16,INK,true));
        challenge.addView(text(GoalChallengeStore.isEnabled(this)?"چالش فعال است":"چالش غیرفعال است",12,GoalChallengeStore.isEnabled(this)?TEAL:MUTED,false));
        LinearLayout challengeButtons=horizontal();Button toggle=GoalChallengeStore.isEnabled(this)?lightButton("غیرفعال‌سازی"):button("فعال‌سازی چالش هدف‌گذاری");Button manage=lightButton("مدیریت اهداف");
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(46),1);challengeButtons.addView(toggle,half);View cg=new View(this);challengeButtons.addView(cg,new LinearLayout.LayoutParams(dp(8),1));challengeButtons.addView(manage,half);LinearLayout.LayoutParams cbp=new LinearLayout.LayoutParams(-1,-2);cbp.topMargin=dp(8);challenge.addView(challengeButtons,cbp);body.addView(challenge);
        toggle.setOnClickListener(v->{GoalChallengeStore.setEnabled(this,!GoalChallengeStore.isEnabled(this));showSettingsPage();});manage.setOnClickListener(v->openGoalChallenge());

        LinearLayout cloud=vertical();cloud.setPadding(dp(16),dp(14),dp(16),dp(14));cloud.setBackground(rounded(WHITE,19));LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,-2);clp.topMargin=dp(11);body.addView(cloud,clp);
        cloud.addView(text("اتصال ایمیل و Google Drive",15,INK,true));cloud.addView(text("اتصال Google Drive فعلاً غیرفعال است",12,MUTED,false));TextView cloudInfo=text("اتصال ابری در این نسخه فعال نیست. برای نگهداری یا انتقال اطلاعات از فایل پشتیبان رمزدار استفاده کن.",11,MUTED,false);LinearLayout.LayoutParams cilp=new LinearLayout.LayoutParams(-1,-2);cilp.topMargin=dp(5);cloud.addView(cloudInfo,cilp);
        Button disabled=lightButton("غیرفعال");disabled.setEnabled(false);LinearLayout.LayoutParams dislp=new LinearLayout.LayoutParams(-1,dp(44));dislp.topMargin=dp(8);cloud.addView(disabled,dislp);disabled.setAlpha(.55f);

        LinearLayout appearance=vertical();appearance.setPadding(dp(16),dp(14),dp(16),dp(14));appearance.setBackground(rounded(WHITE,19));LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,-2);alp.topMargin=dp(11);body.addView(appearance,alp);appearance.addView(text("شخصی‌سازی",16,INK,true));
        Button theme=lightButton("انتخاب تم و رنگ‌ها");Button custom=lightButton("رنگ سفارشی");Button language=lightButton(AppSettings.isEnglish(this)?"App language: English":"زبان برنامه: فارسی");Button font=lightButton("افزودن فونت دلخواه");Button resetFont=lightButton("بازگشت به فونت پیش‌فرض");
        for(Button b:new Button[]{theme,custom,language,font,resetFont}){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(44));lp.topMargin=dp(7);appearance.addView(b,lp);}
        theme.setOnClickListener(v->showThemeDialog());custom.setOnClickListener(v->showCustomColorsDialog());language.setOnClickListener(v->showLanguageDialog());font.setOnClickListener(v->pickFont());resetFont.setOnClickListener(v->{new File(getFilesDir(),AppSettings.fontFileName()).delete();AppSettings.resetTypeface();showSettingsPage();});
        TextView fontInfo=text("برای استفاده از یکان، فایل TTF یا OTF فونت را وارد کن.",11,MUTED,false);fontInfo.setPadding(0,dp(7),0,0);appearance.addView(fontInfo);

        LinearLayout reminder=vertical();reminder.setPadding(dp(16),dp(14),dp(16),dp(14));reminder.setBackground(rounded(WHITE,18));LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,-2);rlp.topMargin=dp(11);body.addView(reminder,rlp);reminder.addView(text("یادآور روزانه",15,INK,true));reminder.addView(text((AppSettings.isEnglish(this)?"Every day at ":"هر روز ساعت ")+timeText(ReminderScheduler.getHour(this),ReminderScheduler.getMinute(this)),13,PRIMARY,true));reminder.setOnClickListener(v->chooseReminderTime());
    }

    private void showThemeDialog(){
        String[] labels={"آبی مینیمال","سبز نعنایی","شن و ماسه","یاسی","خاکستری"};String[] keys={"blue","mint","sand","lavender","graphite"};
        String[] shown=new String[labels.length];for(int i=0;i<labels.length;i++)shown[i]=tr(labels[i]);
        new AlertDialog.Builder(this).setTitle(tr("انتخاب تم")).setItems(shown,(d,which)->{AppSettings.setTheme(this,keys[which]);applyPalette();showSettingsPage();}).setNegativeButton(tr("لغو"),null).show();
    }
    private void showCustomColorsDialog(){
        LinearLayout panel=vertical();panel.setPadding(dp(10),dp(8),dp(10),0);
        EditText bg=new EditText(this),primary=new EditText(this),accent=new EditText(this);
        bg.setSingleLine(true);primary.setSingleLine(true);accent.setSingleLine(true);for(EditText e:new EditText[]{bg,primary,accent}){e.setInputType(android.text.InputType.TYPE_CLASS_TEXT);e.setTextSize(14);e.setTypeface(AppSettings.typeface(this));}
        bg.setHint("#EFF5FD");primary.setHint("#0C4D9F");accent.setHint("#009691");
        panel.addView(text("رنگ پس‌زمینه",12,MUTED,false));panel.addView(bg);panel.addView(text("رنگ اصلی",12,MUTED,false));panel.addView(primary);panel.addView(text("رنگ تأکیدی",12,MUTED,false));panel.addView(accent);
        new AlertDialog.Builder(this).setTitle(tr("رنگ سفارشی")).setView(panel).setNegativeButton(tr("لغو"),null).setPositiveButton(tr("ذخیره رنگ‌ها"),(d,w)->{try{String b=colorInput(bg,"#EFF5FD"),p=colorInput(primary,"#0C4D9F"),a=colorInput(accent,"#009691");Color.parseColor(b);Color.parseColor(p);Color.parseColor(a);AppSettings.setCustomPalette(this,b,p,a);applyPalette();showSettingsPage();}catch(Exception ex){Toast.makeText(this,tr("کد رنگ معتبر نیست؛ از قالب #RRGGBB استفاده کن."),Toast.LENGTH_LONG).show();}}).show();
    }
    private String colorInput(EditText e,String fallback){String s=e.getText().toString().trim();if(s.isEmpty())s=e.getHint().toString();if(!s.startsWith("#"))s="#"+s;return s;}
    private void showLanguageDialog(){String[] labels={"فارسی","English"};new AlertDialog.Builder(this).setTitle(tr("انتخاب زبان")).setSingleChoiceItems(labels,AppSettings.isEnglish(this)?1:0,(d,w)->{AppSettings.setEnglish(this,w==1);d.dismiss();applyPalette();showHome();}).setNegativeButton(tr("لغو"),null).show();}
    private void pickFont(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT_FONT);}
    private void openGoalChallenge(){if(!GoalChallengeStore.isEnabled(this)){new AlertDialog.Builder(this).setTitle(tr("چالش هدف‌گذاری")).setMessage(tr("برای استفاده از چالش، ابتدا آن را فعال کن.")).setNegativeButton(tr("بعداً"),null).setPositiveButton(tr("فعال‌سازی"),(d,w)->{GoalChallengeStore.setEnabled(this,true);startActivity(new Intent(this,GoalChallengeActivity.class));}).show();}else startActivity(new Intent(this,GoalChallengeActivity.class));}
    private void maybeShowChallengeIntro(){if(isFinishing()||GoalChallengeStore.wasPrompted(this))return;GoalChallengeStore.markPrompted(this);new AlertDialog.Builder(this).setTitle(tr("چالش هدف‌گذاری")).setMessage(tr("با تعیین هدف و ثبت انجام آن، نمرهٔ روزت را از پایهٔ ۵ بساز. این قابلیت اختیاری است و هر زمان می‌توانی از تنظیمات فعالش کنی.")).setNegativeButton(tr("فعلاً نه"),(d,w)->{}).setPositiveButton(tr("فعال‌سازی"),(d,w)->{GoalChallengeStore.setEnabled(this,true);openGoalChallenge();}).show();}
    private void showPendingChallengeResult(){if(resultDialogVisible||isFinishing())return;GoalChallengeStore.Evaluation result=GoalChallengeStore.consumePendingResult(this);if(result==null)return;resultDialogVisible=true;LinearLayout panel=vertical();panel.setPadding(dp(18),dp(10),dp(18),dp(8));panel.setGravity(Gravity.CENTER);TextView date=text(result.date.toString(),12,MUTED,false);date.setGravity(Gravity.CENTER);panel.addView(date);TextView score=text(AppSettings.formatScore(this,0),46,TEAL,true);score.setGravity(Gravity.CENTER);panel.addView(score,new LinearLayout.LayoutParams(-1,dp(100)));TextView caption=text("نمرهٔ نهایی روز",13,INK,true);caption.setGravity(Gravity.CENTER);panel.addView(caption);AlertDialog dialog=new AlertDialog.Builder(this).setTitle(tr("نتیجهٔ چالش هدف‌گذاری")).setView(panel).setPositiveButton(tr("باشه"),(d,w)->resultDialogVisible=false).create();dialog.setOnDismissListener(d->resultDialogVisible=false);dialog.show();android.animation.ValueAnimator animator=android.animation.ValueAnimator.ofInt(0,result.scoreTenths);animator.setDuration(1100);animator.setInterpolator(new android.view.animation.OvershootInterpolator());animator.addUpdateListener(a->score.setText(AppSettings.formatScore(this,((Integer)a.getAnimatedValue())/10.0)));animator.start();score.setScaleX(.7f);score.setScaleY(.7f);score.animate().scaleX(1f).scaleY(1f).setDuration(550).start();}

    private void showCalendarPage(){LinearLayout body=makeSubPage("تقویم","تقویم میلادی؛ روزهای بدون نمره خالی می‌مانند.");LinearLayout nav=horizontal();Button prev=lightButton("‹ ماه قبل"),next=lightButton("ماه بعد ›");nav.addView(prev,new LinearLayout.LayoutParams(0,dp(44),1));View gap=new View(this);nav.addView(gap,new LinearLayout.LayoutParams(dp(8),1));nav.addView(next,new LinearLayout.LayoutParams(0,dp(44),1));body.addView(nav);TextView label=text(calendarMonth.getMonth().getDisplayName(TextStyle.FULL,AppSettings.isEnglish(this)?Locale.ENGLISH:new Locale("fa"))+" "+calendarMonth.getYear(),18,INK,true);label.setGravity(Gravity.CENTER);body.addView(label,new LinearLayout.LayoutParams(-1,dp(48)));
        GridLayout grid=new GridLayout(this);grid.setColumnCount(7);grid.setBackground(rounded(WHITE,18));grid.setPadding(dp(5),dp(7),dp(5),dp(7));String[] weekdays=AppSettings.isEnglish(this)?new String[]{"Mon","Tue","Wed","Thu","Fri","Sat","Sun"}:new String[]{"د","س","چ","پ","ج","ش","ی"};for(String day:weekdays){TextView t=text(day,10,MUTED,true);t.setGravity(Gravity.CENTER);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(28);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(t,lp);}
        int offset=calendarMonth.atDay(1).getDayOfWeek().getValue()-1;for(int i=0;i<offset;i++){TextView blank=text("",10,MUTED,false);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(56);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(blank,lp);}
        for(int day=1;day<=calendarMonth.lengthOfMonth();day++){LocalDate date=calendarMonth.atDay(day);Integer score=ScoreStore.getTenths(this,date);TextView cell=text(AppSettings.digits(this,String.valueOf(day))+(score==null?"":"\n"+AppSettings.formatScore(this,score/10.0)),score==null?12:10,score==null?MUTED:PRIMARY,score!=null);cell.setGravity(Gravity.CENTER);cell.setBackground(rounded(score==null?BG:PALE,8));GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(56);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);lp.setMargins(dp(2),dp(2),dp(2),dp(2));grid.addView(cell,lp);cell.setOnClickListener(v->{if(score==null){new AlertDialog.Builder(this).setMessage(tr("برای ")+date+tr(" نمره‌ای ثبت نشده است.")).setPositiveButton(tr("باشه"),null).show();}else new AlertDialog.Builder(this).setTitle(date.toString()).setMessage(tr("نمره:")+" "+AppSettings.formatScore(this,score/10.0)).setNegativeButton(tr("بستن"),null).setPositiveButton(tr("ویرایش"),(d,w)->showScoreForDate(date)).show();});}
        LinearLayout.LayoutParams glp=new LinearLayout.LayoutParams(-1,-2);body.addView(grid,glp);prev.setOnClickListener(v->{calendarMonth=calendarMonth.minusMonths(1);showCalendarPage();});next.setOnClickListener(v->{calendarMonth=calendarMonth.plusMonths(1);showCalendarPage();});
    }
    private void showScoreForDate(LocalDate date){Integer saved=ScoreStore.getTenths(this,date);NumberPicker picker=new NumberPicker(this);picker.setMinValue(0);picker.setMaxValue(100);String[] vals=new String[101];for(int i=0;i<=100;i++)vals[i]=AppSettings.formatScore(this,i/10.0);picker.setDisplayedValues(vals);picker.setValue(saved==null?50:saved);new AlertDialog.Builder(this).setTitle(tr("نمرهٔ ")+date).setView(picker).setNegativeButton(tr("لغو"),null).setPositiveButton(tr("ذخیره"),(d,w)->{ScoreStore.saveScore(this,date,picker.getValue());showCalendarPage();}).show();}

    private void showBackupPage(){LinearLayout body=makeSubPage("پشتیبان‌گیری","فایل رمزدار بساز یا نمره‌ها را بازیابی کن.");body.addView(actionCard("ساخت فایل پشتیبان رمزدار","تمام نمره‌های تاریخ‌دار در یک فایل رمزگذاری می‌شوند.","↓",this::askExportPassword),new LinearLayout.LayoutParams(-1,dp(130)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(130));lp.topMargin=dp(12);body.addView(actionCard("بازیابی از فایل","فایل پشتیبان را انتخاب کن و رمز آن را وارد کن.","↑",this::askImportPassword),lp);TextView warning=text("رمزگذاری با AES-GCM انجام می‌شود. رمز را جداگانه نگه دار؛ بدون آن فایل بازیابی نمی‌شود. ورود اطلاعات، تاریخ‌های داخل فایل را جایگزین می‌کند و تاریخ‌های دیگر را دست‌نخورده می‌گذارد.",12,MUTED,false);warning.setPadding(dp(4),dp(14),dp(4),0);body.addView(warning);}
    private void askExportPassword(){EditText input=new EditText(this);input.setTypeface(AppSettings.typeface(this));input.setHint(tr("رمز فایل (حداقل ۸ نویسه)"));input.setInputType(129);new AlertDialog.Builder(this).setTitle(tr("رمزگذاری فایل")).setView(input).setNegativeButton(tr("لغو"),null).setPositiveButton(tr("ادامه"),(d,w)->{String p=input.getText().toString();if(p.length()<8){Toast.makeText(this,tr("رمز باید حداقل ۸ نویسه باشد."),Toast.LENGTH_LONG).show();return;}pendingBackupPassword=p.toCharArray();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"nomrenegar-backup.nrb");startActivityForResult(i,CREATE_BACKUP);}).show();}
    private void askImportPassword(){EditText input=new EditText(this);input.setTypeface(AppSettings.typeface(this));input.setHint(tr("رمز فایل"));input.setInputType(129);new AlertDialog.Builder(this).setTitle(tr("بازیابی پشتیبان")).setView(input).setNegativeButton(tr("لغو"),null).setPositiveButton(tr("انتخاب فایل"),(d,w)->{pendingBackupPassword=input.getText().toString().toCharArray();Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,OPEN_BACKUP);}).show();}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==IMPORT_FONT){
            if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
            File target=new File(getFilesDir(),AppSettings.fontFileName());File temp=new File(getFilesDir(),"font_import.tmp");
            try(InputStream in=getContentResolver().openInputStream(data.getData());OutputStream out=new FileOutputStream(temp)){
                if(in==null)throw new java.io.IOException(tr("فایل فونت قابل خواندن نیست."));byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))>0)out.write(buffer,0,n);out.flush();
                android.graphics.Typeface.createFromFile(temp);
                if(target.exists())target.delete();if(!temp.renameTo(target))throw new java.io.IOException(tr("ذخیرهٔ فونت انجام نشد."));AppSettings.resetTypeface();AppSettings.typeface(this);Toast.makeText(this,tr("فونت اضافه شد."),Toast.LENGTH_LONG).show();showSettingsPage();
            }catch(Exception ex){temp.delete();Toast.makeText(this,tr("فایل فونت معتبر نیست؛ فایل TTF یا OTF انتخاب کن."),Toast.LENGTH_LONG).show();}
            return;
        }
        if(resultCode!=RESULT_OK||data==null||data.getData()==null){pendingBackupPassword=null;return;}Uri uri=data.getData();
        try{if(requestCode==CREATE_BACKUP&&pendingBackupPassword!=null){try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new java.io.IOException(tr("امکان نوشتن فایل وجود ندارد."));EncryptedBackup.write(this,out,pendingBackupPassword);}exportedUri=uri;new AlertDialog.Builder(this).setTitle(tr("پشتیبان ذخیره شد")).setMessage(tr("فایل رمزگذاری‌شده ذخیره شد. می‌خواهی آن را ارسال کنی؟")).setNegativeButton(tr("بعداً"),null).setPositiveButton(tr("ارسال فایل"),(d,w)->shareBackup(uri)).show();}else if(requestCode==OPEN_BACKUP&&pendingBackupPassword!=null){try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new java.io.IOException(tr("امکان خواندن فایل وجود ندارد."));EncryptedBackup.read(this,in,pendingBackupPassword);}Toast.makeText(this,tr("نمره‌ها بازیابی شدند."),Toast.LENGTH_LONG).show();GoalChallengeWorker.scheduleNext(this);showHome();}}catch(Exception ex){Toast.makeText(this,tr("عملیات ناموفق بود؛ رمز یا فایل را بررسی کن."),Toast.LENGTH_LONG).show();}finally{pendingBackupPassword=null;}
    }
    private void shareBackup(Uri uri){try{Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/octet-stream");send.putExtra(Intent.EXTRA_STREAM,uri);send.setClipData(ClipData.newUri(getContentResolver(),AppSettings.isEnglish(this)?"NomreNegar backup file":"نمره‌نگار - فایل پشتیبان",uri));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,tr("ارسال فایل پشتیبان")));}catch(Exception e){Toast.makeText(this,tr("امکان باز کردن بخش ارسال فایل وجود ندارد."),Toast.LENGTH_LONG).show();}}

    private void chooseReminderTime(){int hour=ReminderScheduler.getHour(this),minute=ReminderScheduler.getMinute(this);TimePickerDialog dialog=new TimePickerDialog(this,(view,h,m)->{ReminderScheduler.saveTime(this,h,m);if("home".equals(currentPage))showHome();if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S&&!ReminderScheduler.canSchedulePrecisely(this))new AlertDialog.Builder(this).setTitle(tr("اجازهٔ اعلان سرِ ساعت")).setMessage(tr("برای اجرای دقیق در ساعت انتخاب‌شده، دسترسی آلارم دقیق را فعال کن؛ در غیر این صورت اعلان ممکن است با تأخیر برسد.")).setNegativeButton(tr("بعداً"),null).setPositiveButton(tr("رفتن به تنظیمات"),(d,w)->{try{startActivity(ReminderScheduler.exactAlarmSettingsIntent(this));}catch(Exception ex){Toast.makeText(this,tr("تنظیمات آلارم در این دستگاه در دسترس نیست."),Toast.LENGTH_LONG).show();}}).show();},hour,minute,true);dialog.setTitle(tr("ساعت یادآور روزانه"));dialog.show();}
    private String timeText(int h,int m){return AppSettings.digits(this,String.format(Locale.US,"%02d:%02d",h,m));}
}
