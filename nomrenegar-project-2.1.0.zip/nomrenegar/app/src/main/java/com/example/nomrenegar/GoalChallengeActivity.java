package com.example.nomrenegar;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** UI for daily goals, recurring weekday goals and previous-day suggestions. */
public final class GoalChallengeActivity extends Activity {
    private int bg,white,ink,muted,primary,pale,accent;
    private LocalDate today;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        applyPalette();
        today=LocalDate.now();
        GoalChallengeStore.evaluateClosedDays(this,today);
        GoalChallengeWorker.scheduleNext(this);
        render();
        GoalChallengeStore.Evaluation result=GoalChallengeStore.consumePendingResult(this);
        if(result!=null) getWindow().getDecorView().post(()->showResult(result));
    }

    @Override protected void onResume() {
        super.onResume();
        LocalDate current=LocalDate.now();
        if(today!=null && !today.equals(current)) {
            today=current;
            GoalChallengeStore.evaluateClosedDays(this,current);
            GoalChallengeWorker.scheduleNext(this);
            render();
            GoalChallengeStore.Evaluation result=GoalChallengeStore.consumePendingResult(this);
            if(result!=null) getWindow().getDecorView().post(()->showResult(result));
        }
    }

    private void applyPalette(){AppSettings.Palette p=AppSettings.palette(this);bg=p.bg;white=p.white;ink=p.ink;muted=p.muted;primary=p.primary;pale=p.pale;accent=p.accent;getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(white);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,float radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private String tr(String s){return AppSettings.tr(this,s);}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(tr(value));t.setTextSize(size);t.setTextColor(color);t.setGravity((AppSettings.isEnglish(this)?Gravity.LEFT:Gravity.RIGHT)|Gravity.CENTER_VERTICAL);t.setTextDirection(AppSettings.isEnglish(this)?View.TEXT_DIRECTION_LTR:View.TEXT_DIRECTION_RTL);t.setTypeface(AppSettings.typeface(this),bold?Typeface.BOLD:Typeface.NORMAL);return t;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(AppSettings.isEnglish(this)?View.LAYOUT_DIRECTION_LTR:View.LAYOUT_DIRECTION_RTL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);l.setLayoutDirection(AppSettings.isEnglish(this)?View.LAYOUT_DIRECTION_LTR:View.LAYOUT_DIRECTION_RTL);return l;}
    private Button button(String label,boolean primaryButton){Button b=new Button(this);b.setText(tr(label));b.setAllCaps(false);b.setTextSize(14);b.setTypeface(AppSettings.typeface(this),Typeface.BOLD);b.setTextColor(primaryButton?Color.WHITE:primary);b.setBackground(shape(primaryButton?primary:pale,15));b.setMinHeight(dp(44));return b;}

    private void render(){
        LinearLayout root=vertical();root.setBackgroundColor(bg);
        LinearLayout top=horizontal();top.setPadding(dp(16),dp(9),dp(16),dp(9));
        TextView back=text("‹",30,primary,true);back.setGravity(Gravity.CENTER);back.setBackground(shape(white,13));back.setOnClickListener(v->finish());top.addView(back,new LinearLayout.LayoutParams(dp(44),dp(42)));
        LinearLayout titleBox=vertical();titleBox.setPadding(dp(12),0,dp(8),0);titleBox.addView(text("چالش هدف‌گذاری",19,ink,true));
        String dateLabel=today.getMonth().getDisplayName(TextStyle.FULL,AppSettings.isEnglish(this)?Locale.ENGLISH:new Locale("fa"))+" "+AppSettings.digits(this,today.toString());
        titleBox.addView(text(dateLabel,11,muted,false));top.addView(titleBox,new LinearLayout.LayoutParams(0,dp(50),1));
        TextView state=text(AppSettings.formatScore(this,5),19,accent,true);state.setGravity(Gravity.CENTER);state.setBackground(shape(white,30));top.addView(state,new LinearLayout.LayoutParams(dp(42),dp(42)));root.addView(top);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);LinearLayout body=vertical();body.setPadding(dp(16),dp(7),dp(16),dp(24));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout intro=card();intro.addView(text("پایهٔ نمره ۵ است؛ هدف انجام‌شده امتیاز مثبت و هدف انجام‌نشده امتیاز منفی دارد.",13,muted,false));TextView details=text("هر هدف از ۰٫۱ تا ۵ امتیاز دارد. نمرهٔ نهایی در پایان روز بین صفر تا ۱۰ محدود می‌شود.",11,muted,false);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,-2);dlp.topMargin=dp(5);intro.addView(details,dlp);body.addView(intro,margin(0,0,0,12));

        LinearLayout daily=sectionHeader("اهداف روزانه","افزودن هدف روزانه",()->showAddGoal(false));body.addView(daily,margin(0,0,0,4));
        List<GoalChallengeStore.Goal> todayGoals=GoalChallengeStore.dailyGoals(this,today);
        if(todayGoals.isEmpty())body.addView(empty("هنوز هدف روزانه‌ای ثبت نکرده‌ای."),margin(0,0,0,10));
        for(GoalChallengeStore.Goal goal:todayGoals)body.addView(goalRow(goal,false,true),margin(0,0,0,7));

        List<GoalChallengeStore.Goal> suggestions=GoalChallengeStore.suggestionsFromPreviousDay(this,today);
        if(!suggestions.isEmpty()){
            LinearLayout suggest=card();suggest.addView(text("پیشنهاد از اهداف روز گذشته",14,ink,true));
            for(GoalChallengeStore.Goal g:suggestions){LinearLayout row=horizontal();TextView label=text(g.name+" · "+AppSettings.formatScore(this,g.weight()),12,muted,false);row.addView(label,new LinearLayout.LayoutParams(0,dp(38),1));TextView add=text("+",22,accent,true);add.setGravity(Gravity.CENTER);add.setBackground(shape(pale,11));row.addView(add,new LinearLayout.LayoutParams(dp(38),dp(34)));add.setOnClickListener(v->{GoalChallengeStore.addSuggestion(this,today,g);render();});suggest.addView(row);}
            body.addView(suggest,margin(0,0,0,12));
        }

        LinearLayout recurring=sectionHeader("اهداف مستمر","افزودن هدف مستمر",()->showAddGoal(true));body.addView(recurring,margin(0,0,0,4));
        List<GoalChallengeStore.Goal> definitions=GoalChallengeStore.recurringDefinitions(this);
        List<GoalChallengeStore.Goal> active=GoalChallengeStore.goalsForDate(this,today);
        for(GoalChallengeStore.Goal def:definitions){boolean activeToday=false,done=false;for(GoalChallengeStore.Goal a:active)if(a.id.equals(def.id)){activeToday=true;done=a.done;break;}body.addView(recurringRow(def,activeToday,done),margin(0,0,0,7));}
        if(definitions.isEmpty())body.addView(empty("هنوز هدف مستمری ثبت نکرده‌ای."),margin(0,0,0,10));

        LinearLayout footer=card();footer.addView(text("محاسبهٔ خودکار نمره",14,ink,true));footer.addView(text("چند دقیقه بعد از نیمه‌شب، تیک‌های روز قبل بررسی می‌شوند و نمره در نمودار و تقویم ثبت می‌شود.",12,muted,false));body.addView(footer,margin(0,dp(12),0,0));
        root.setFocusableInTouchMode(true);setContentView(root);
    }

    private LinearLayout sectionHeader(String title,String action,Runnable onClick){LinearLayout row=horizontal();TextView h=text(title,17,ink,true);row.addView(h,new LinearLayout.LayoutParams(0,dp(48),1));Button add=button("+ "+tr(action),false);add.setTextSize(12);add.setOnClickListener(v->onClick.run());row.addView(add,new LinearLayout.LayoutParams(-2,dp(40)));return row;}
    private LinearLayout card(){LinearLayout c=vertical();c.setPadding(dp(14),dp(12),dp(14),dp(12));c.setBackground(shape(white,17));c.setElevation(dp(1));return c;}
    private TextView empty(String s){TextView t=text(s,12,muted,false);t.setPadding(dp(6),dp(12),dp(6),dp(12));t.setBackground(shape(white,14));return t;}
    private LinearLayout.LayoutParams margin(int left,int top,int right,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(left),dp(top),dp(right),dp(bottom));return p;}

    private View goalRow(GoalChallengeStore.Goal goal,boolean recurring,boolean allowDelete){
        LinearLayout row=card();LinearLayout line=horizontal();CheckBox check=new CheckBox(this);check.setText(goal.name+"  ·  "+AppSettings.formatScore(this,goal.weight()));check.setTextSize(13);check.setTextColor(ink);check.setTypeface(AppSettings.typeface(this));check.setButtonTintList(android.content.res.ColorStateList.valueOf(accent));check.setChecked(goal.done);line.addView(check,new LinearLayout.LayoutParams(0,dp(45),1));
        if(allowDelete){TextView del=text("×",22,muted,true);del.setGravity(Gravity.CENTER);line.addView(del,new LinearLayout.LayoutParams(dp(36),dp(38)));del.setOnClickListener(v->{new AlertDialog.Builder(this).setMessage(tr("این هدف حذف شود؟")).setNegativeButton(tr("لغو"),null).setPositiveButton(tr("حذف"),(d,w)->{GoalChallengeStore.deleteDaily(this,today,goal.id);render();}).show();});}
        row.addView(line);check.setOnCheckedChangeListener((b,checked)->GoalChallengeStore.toggleDaily(this,today,goal.id,checked));return row;
    }

    private View recurringRow(GoalChallengeStore.Goal goal,boolean activeToday,boolean done){
        LinearLayout row=card();LinearLayout line=horizontal();CheckBox check=new CheckBox(this);check.setText(goal.name+"  ·  "+AppSettings.formatScore(this,goal.weight()));check.setTextSize(13);check.setTextColor(activeToday?ink:muted);check.setTypeface(AppSettings.typeface(this));check.setButtonTintList(android.content.res.ColorStateList.valueOf(accent));check.setChecked(done);check.setEnabled(activeToday);line.addView(check,new LinearLayout.LayoutParams(0,dp(42),1));TextView del=text("×",22,muted,true);del.setGravity(Gravity.CENTER);line.addView(del,new LinearLayout.LayoutParams(dp(34),dp(38)));row.addView(line);
        TextView days=text(GoalChallengeStore.daysLabel(this,goal.daysMask),11,muted,false);row.addView(days);
        if(!activeToday)row.addView(text(tr("در برنامهٔ امروز نیست"),10,muted,false));
        check.setOnCheckedChangeListener((b,checked)->GoalChallengeStore.toggleRecurring(this,today,goal.id,checked));
        del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage(tr("این هدف مستمر حذف شود؟")).setNegativeButton(tr("لغو"),null).setPositiveButton(tr("حذف"),(d,w)->{GoalChallengeStore.deleteRecurring(this,goal.id);render();}).show());return row;
    }

    private void showAddGoal(boolean recurring){
        LinearLayout panel=vertical();panel.setPadding(dp(8),dp(8),dp(8),0);
        EditText name=new EditText(this);name.setSingleLine(true);name.setTextSize(14);name.setTypeface(AppSettings.typeface(this));name.setHint(tr("عنوان هدف"));panel.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        TextView weightLabel=text("امتیاز هدف (۰٫۱ تا ۵)",12,muted,false);panel.addView(weightLabel);
        NumberPicker weight=new NumberPicker(this);weight.setMinValue(1);weight.setMaxValue(50);weight.setValue(10);String[] values=new String[50];for(int i=1;i<=50;i++)values[i-1]=AppSettings.formatScore(this,i/10.0);weight.setDisplayedValues(values);weight.setWrapSelectorWheel(false);panel.addView(weight,new LinearLayout.LayoutParams(-1,dp(125)));
        CheckBox[] days=new CheckBox[7];
        if(recurring){panel.addView(text("روزهای تکرار",13,ink,true));LinearLayout first=horizontal(),second=horizontal();String[] fa={"دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه","یکشنبه"};String[] en={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};for(int i=0;i<7;i++){days[i]=new CheckBox(this);days[i].setText(AppSettings.isEnglish(this)?en[i]:fa[i]);days[i].setTextSize(10);days[i].setTypeface(AppSettings.typeface(this));days[i].setChecked(i<5);(i<4?first:second).addView(days[i],new LinearLayout.LayoutParams(0,dp(42),1));}panel.addView(first);panel.addView(second);}
        new AlertDialog.Builder(this).setTitle(tr(recurring?"افزودن هدف مستمر":"افزودن هدف روزانه")).setView(panel).setNegativeButton(tr("لغو"),null).setPositiveButton(tr("ذخیره"),(dialog,which)->{
            String title=name.getText().toString().trim();if(title.isEmpty()){Toast.makeText(this,tr("عنوان هدف را وارد کن."),Toast.LENGTH_SHORT).show();return;}
            if(recurring){int mask=0;for(int i=0;i<7;i++)if(days[i].isChecked())mask|=(1<<i);if(mask==0){Toast.makeText(this,tr("حداقل یک روز انتخاب کن."),Toast.LENGTH_SHORT).show();return;}GoalChallengeStore.addRecurringGoal(this,title,weight.getValue(),mask);}
            else GoalChallengeStore.addDailyGoal(this,today,title,weight.getValue());
            render();
        }).show();
    }

    private void showResult(GoalChallengeStore.Evaluation result){
        LinearLayout panel=vertical();panel.setGravity(Gravity.CENTER);panel.setPadding(dp(20),dp(20),dp(20),dp(20));
        TextView date=text(result.date.toString(),12,muted,false);date.setGravity(Gravity.CENTER);panel.addView(date);
        TextView score=text(AppSettings.formatScore(this,0),48,accent,true);score.setGravity(Gravity.CENTER);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(100));panel.addView(score,lp);
        TextView caption=text("نمرهٔ نهایی روز",13,ink,true);caption.setGravity(Gravity.CENTER);panel.addView(caption);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(tr("نتیجهٔ چالش هدف‌گذاری")).setView(panel).setPositiveButton(tr("باشه"),null).create();dialog.show();
        android.animation.ValueAnimator animator=android.animation.ValueAnimator.ofInt(0,result.scoreTenths);animator.setDuration(1100);animator.setInterpolator(new android.view.animation.OvershootInterpolator());animator.addUpdateListener(a->score.setText(AppSettings.formatScore(this,((Integer)a.getAnimatedValue())/10.0)));animator.start();
        score.setScaleX(.65f);score.setScaleY(.65f);score.animate().scaleX(1f).scaleY(1f).setDuration(550).start();
    }
}
