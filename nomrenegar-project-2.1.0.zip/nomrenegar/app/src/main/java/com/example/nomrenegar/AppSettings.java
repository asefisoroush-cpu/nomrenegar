package com.example.nomrenegar;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;

import java.io.File;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Persistent presentation preferences: language, color palette and imported typeface. */
public final class AppSettings {
    private static final String PREFS = "ui_settings_v1";
    private static final String KEY_LANGUAGE = "language";
    private static final String KEY_THEME = "theme";
    private static final String KEY_CUSTOM_BG = "custom_bg";
    private static final String KEY_CUSTOM_PRIMARY = "custom_primary";
    private static final String KEY_CUSTOM_ACCENT = "custom_accent";
    private static final String FONT_FILE = "custom_font.ttf";
    private static Typeface cachedTypeface;
    private static final Map<String, String> EN = new HashMap<>();

    static {
        map("نمره‌نگار", "NomreNegar");
        map("نمره‌نگار - فایل پشتیبان", "NomreNegar backup file");
        map("اتصال Google Drive فعلاً غیرفعال است", "Google Drive connection is currently disabled");
        map("پایهٔ نمره ۵ است؛ هدف انجام‌شده امتیاز مثبت و هدف انجام‌نشده امتیاز منفی دارد.", "The base score is 5. Completed goals add points; incomplete goals subtract them.");
        map("منو", "Menu"); map("ثبت روزانه و مرور روند", "Daily scores and progress");
        map("اتصال ایمیل و Google Drive", "Email and Google Drive connection");
        map("ثبت روزانه و مرور روند", "Daily scores and progress");
        map("اخیر", "Recent"); map("تقویمی", "Calendar");
        map("۷ روز اخیر", "Last 7 days"); map("۳۰ روز اخیر", "Last 30 days"); map("۳۶۵ روز اخیر", "Last 365 days");
        map("هفتهٔ جاری میلادی", "Current week"); map("ماه جاری میلادی", "Current month"); map("سال جاری میلادی", "Current year");
        map("میانگین این بازه", "Period average");
        map("فقط روزهای ثبت‌شده در نمودار و میانگین حساب می‌شوند.", "Only recorded days are included in the chart and average.");
        map("ثبت امروز", "Record today"); map("نمرهٔ امروز هنوز ثبت نشده", "Today's score has not been recorded");
        map("نمرهٔ امروز ثبت شده؛ برای ویرایش بزن.", "Today's score is saved. Tap to edit.");
        map("نمره ذخیره شد.", "Score saved."); map("ثبت نمرهٔ امروز", "Record today's score"); map("ویرایش نمرهٔ امروز", "Edit today's score");
        map("منو", "Menu"); map("تنظیمات", "Settings"); map("تقویم", "Calendar"); map("پشتیبان‌گیری", "Backup");
        map("چالش هدف‌گذاری", "Goal Challenge"); map("فایل پشتیبان بساز یا نمره‌ها را بازیابی کن.", "Create a backup or restore your scores.");
        map("تنظیمات ظاهری و یادآور روزانه", "Appearance and daily reminder");
        map("اتصال ایمیل و Google Drive", "Email and Google Drive connection");
        map("پشتیبان‌گیری خودکار", "Automatic backup");
        map("اتصال Google Drive فعلاً غیرفعال است", "Google Drive connection is currently disabled");
        map("اتصال ابری در این نسخه فعال نیست. برای نگهداری یا انتقال اطلاعات از فایل پشتیبان رمزدار استفاده کن.", "Cloud backup is unavailable in this version. Use an encrypted backup file to preserve or transfer your data.");
        map("یادآور روزانه", "Daily reminder"); map("ساعت یادآور روزانه", "Daily reminder time");
        map("انتخاب زبان", "Choose language"); map("فارسی", "Persian"); map("English", "English"); map("زبان برنامه", "App language");
        map("قالب رنگی", "Color theme"); map("انتخاب تم", "Choose a theme"); map("آبی مینیمال", "Minimal blue");
        map("سبز نعنایی", "Mint green"); map("شن و ماسه", "Sand"); map("یاسی", "Lavender"); map("خاکستری", "Soft graphite"); map("رنگ سفارشی", "Custom colors");
        map("رنگ پس‌زمینه", "Background color"); map("رنگ اصلی", "Primary color"); map("رنگ تأکیدی", "Accent color"); map("ذخیره رنگ‌ها", "Save colors");
        map("فونت برنامه", "App font"); map("افزودن فونت دلخواه", "Import custom font"); map("بازگشت به فونت پیش‌فرض", "Use default font");
        map("برای استفاده از یکان، فایل TTF یا OTF فونت را وارد کن.", "To use Yekan, import its TTF or OTF font file.");
        map("فعالسازی چالش هدف‌گذاری", "Enable Goal Challenge"); map("چالش فعال است", "Challenge is enabled"); map("چالش غیرفعال است", "Challenge is disabled");
        map("فعالسازی", "Enable"); map("غیرفعال‌سازی", "Disable"); map("فعلاً نه", "Not now"); map("بعداً", "Later");
        map("بستن", "Close"); map("ذخیره", "Save"); map("لغو", "Cancel"); map("ادامه", "Continue"); map("باشه", "OK");
        map("تاریخ میلادی: ", "Gregorian date: "); map("نمرهٔ ", "Score for "); map("نمره:", "Score:");
        map("هیچ نمره‌ای در این بازه ثبت نشده", "No scores recorded in this period");
        map("بر پایهٔ ", "Based on "); map(" روز ثبت‌شده از ", " recorded days out of "); map(" روز", " days");
        map("ماه قبل", "Previous month"); map("ماه بعد", "Next month");
        map("ساخت فایل پشتیبان رمزدار", "Create encrypted backup"); map("تمام نمره‌های تاریخ‌دار در یک فایل رمزگذاری می‌شوند.", "All dated scores are stored in one encrypted file.");
        map("بازیابی از فایل", "Restore from file"); map("فایل پشتیبان را انتخاب کن و رمز آن را وارد کن.", "Choose a backup file and enter its password.");
        map("رمزگذاری با AES-GCM انجام می‌شود. رمز را جداگانه نگه دار؛ بدون آن فایل بازیابی نمی‌شود. ورود اطلاعات، تاریخ‌های داخل فایل را جایگزین می‌کند و تاریخ‌های دیگر را دست‌نخورده می‌گذارد.", "Backups use AES-GCM encryption. Keep the password separately; the file cannot be restored without it. Imported dates replace matching dates while other dates remain unchanged.");
        map("رمز فایل (حداقل ۸ نویسه)", "Backup password (at least 8 characters)"); map("رمز فایل", "Backup password"); map("رمزگذاری فایل", "Encrypt backup"); map("بازیابی پشتیبان", "Restore backup"); map("انتخاب فایل", "Choose file");
        map("رمز باید حداقل ۸ نویسه باشد.", "The password must contain at least 8 characters.");
        map("پشتیبان ذخیره شد", "Backup saved"); map("فایل رمزگذاری‌شده ذخیره شد. می‌خواهی آن را ارسال کنی؟", "The encrypted file was saved. Do you want to share it?"); map("ارسال فایل", "Share file");
        map("نمره‌ها بازیابی شدند.", "Scores restored."); map("عملیات ناموفق بود؛ رمز یا فایل را بررسی کن.", "Operation failed. Check the password or file.");
        map("برای این بازه هنوز نمره‌ای ثبت نشده", "No scores have been recorded in this period");
        map("چالش هدف‌گذاری", "Goal Challenge"); map("پایهٔ نمره ۵ است؛ هدف انجام‌شده امتیاز مثبت و هدف انجام‌نشده امتیاز منفی دارد.", "The base score is 5. Completed goals add points; incomplete goals subtract them.");
        map("مدیریت اهداف روزانه و مستمر", "Manage daily and recurring goals"); map("مدیریت اهداف", "Manage goals");
        map("ظاهر، زبان و یادآور روزانه", "Appearance, language and daily reminder"); map("شخصی‌سازی", "Personalization");
        map("اهداف روزانه", "Daily goals"); map("اهداف مستمر", "Recurring goals");
        map("افزودن هدف روزانه", "Add daily goal"); map("افزودن هدف مستمر", "Add recurring goal");
        map("+ افزودن هدف روزانه", "+ Add daily goal"); map("+ افزودن هدف مستمر", "+ Add recurring goal");
        map("عنوان هدف", "Goal title"); map("امتیاز هدف (۰٫۱ تا ۵)", "Goal points (0.1 to 5)"); map("امتیاز هدف", "Goal points"); map("روزهای تکرار", "Repeat on");
        map("هر هدف از ۰٫۱ تا ۵ امتیاز دارد. نمرهٔ نهایی در پایان روز بین صفر تا ۱۰ محدود می‌شود.", "Each goal is worth 0.1 to 5 points. The final daily score is limited to 0–10.");
        map("هنوز هدف روزانه‌ای ثبت نکرده‌ای.", "You have not added any daily goals yet."); map("هنوز هدف مستمری ثبت نکرده‌ای.", "You have not added any recurring goals yet.");
        map("پیشنهاد از اهداف روز گذشته", "Suggestions from yesterday"); map("محاسبهٔ خودکار نمره", "Automatic score calculation");
        map("چند دقیقه بعد از نیمه‌شب، تیک‌های روز قبل بررسی می‌شوند و نمره در نمودار و تقویم ثبت می‌شود.", "A few minutes after midnight, yesterday's checkmarks are evaluated and the score is added to the chart and calendar.");
        map("در برنامهٔ امروز نیست", "Not scheduled for today"); map("این هدف حذف شود؟", "Delete this goal?"); map("این هدف مستمر حذف شود؟", "Delete this recurring goal?");
        map("حذف", "Delete"); map("افزودن هدف", "Add goal"); map("هدف را وارد کن", "Enter a goal");
        map("عنوان هدف را وارد کن.", "Enter a goal title."); map("حداقل یک روز انتخاب کن.", "Select at least one day.");
        map("فعال‌سازی", "Enable"); map("فعال‌سازی چالش هدف‌گذاری", "Enable Goal Challenge"); map("چالش فعال است", "Challenge is enabled"); map("چالش غیرفعال است", "Challenge is disabled");
        map("نتیجهٔ چالش هدف‌گذاری", "Goal Challenge result"); map("نمرهٔ نهایی روز", "Final daily score");
        map("با تعیین هدف و ثبت انجام آن، نمرهٔ روزت را از پایهٔ ۵ بساز. این قابلیت اختیاری است و هر زمان می‌توانی از تنظیمات فعالش کنی.", "Set goals and mark them complete to build your daily score from a base of 5. This feature is optional and can be enabled later in Settings.");
        map("برای استفاده از چالش، ابتدا آن را فعال کن.", "Enable the challenge before using it.");
        map("تقویم میلادی؛ روزهای بدون نمره خالی می‌مانند.", "Gregorian calendar. Days without scores are left blank.");
        map("برای ", "No score was recorded for "); map(" نمره‌ای ثبت نشده است.", ".");
        map("ویرایش", "Edit"); map("نمرهٔ نهایی روز", "Final daily score");
        map("پشتیبان‌گیری", "Backup"); map("فایل رمزدار بساز یا نمره‌ها را بازیابی کن.", "Create a password-protected backup or restore scores.");
        map("برای استفاده از یکان، فایل TTF یا OTF فونت را وارد کن.", "To use Yekan, import its TTF or OTF font file.");
        map("فونت اضافه شد.", "Font imported."); map("فایل فونت معتبر نیست؛ فایل TTF یا OTF انتخاب کن.", "The font file is invalid. Choose a TTF or OTF file.");
        map("کد رنگ معتبر نیست؛ از قالب #RRGGBB استفاده کن.", "Invalid color code. Use the #RRGGBB format.");
        map("هر روز ساعت ", "Every day at ");
        map("ساخت فایل پشتیبان رمزدار", "Create encrypted backup");
        map("اجازهٔ اعلان سرِ ساعت", "Exact-time alarm permission");
        map("برای اجرای دقیق در ساعت انتخاب‌شده، دسترسی آلارم دقیق را فعال کن؛ در غیر این صورت اعلان ممکن است با تأخیر برسد.", "Enable exact alarms to run at the selected time. Otherwise, the reminder may be delayed.");
        map("رفتن به تنظیمات", "Open settings"); map("تنظیمات آلارم در این دستگاه در دسترس نیست.", "Alarm settings are unavailable on this device.");
        map("بر پایهٔ ", "Based on ");
        map("نمره‌های روزانه در تقویم میلادی", "Daily scores in the Gregorian calendar"); map("ساخت و بازیابی فایل پشتیبان", "Create and restore backups");
        map("‹ قبلی", "‹ Previous"); map("بعدی ›", "Next ›"); map("‹ ماه قبل", "‹ Previous month"); map("ماه بعد ›", "Next month ›");
        map("انتخاب تم و رنگ‌ها", "Choose theme and colors"); map("غیرفعال", "Disabled"); map("مدیریت اهداف", "Manage goals");
        map("نمرهٔ امروز هنوز ثبت نشده", "Today's score has not been recorded"); map("نمره ذخیره شد.", "Score saved.");
        map("پشتیبان‌گیری", "Backup"); map("نمرهٔ روز گذشته:", "Yesterday's score:");
        map("پشتیبان‌گیری خودکار", "Automatic backup"); map("تمام نمره‌های تاریخ‌دار در یک فایل رمزگذاری می‌شوند.", "All dated scores are stored in one encrypted file.");
        map("فایل رمزدار بساز یا نمره‌ها را بازیابی کن.", "Create an encrypted backup or restore scores.");
        map("امکان باز کردن بخش ارسال فایل وجود ندارد.", "Unable to open the sharing menu."); map("ارسال فایل پشتیبان", "Share backup file");
        map("ثبت نمرهٔ امروز", "Record today's score"); map("نمرهٔ امروز", "Today's score");
        map("جمع نمرات", "Score summary"); map("بستن", "Close"); map("بعدی", "Next"); map("قبلی", "Previous");
        map("مدیریت اهداف روزانه و مستمر", "Manage daily and recurring goals"); map("ظاهر، زبان و یادآور روزانه", "Appearance, language and daily reminder");
        map("اتصال ابری در این نسخه فعال نیست. برای نگهداری یا انتقال اطلاعات از فایل پشتیبان رمزدار استفاده کن.", "Cloud backup is unavailable in this version. Use an encrypted backup file to preserve or transfer your data.");
        map("نمرهٔ امروز ثبت شده؛ برای ویرایش بزن.", "Today's score is saved. Tap to edit.");
        map("فقط روزهای ثبت‌شده در نمودار و میانگین حساب می‌شوند.", "Only recorded days are included in the chart and average.");
        map("امکان نوشتن فایل وجود ندارد.", "Cannot write the file."); map("امکان خواندن فایل وجود ندارد.", "Cannot read the file.");
        map("فایل فونت قابل خواندن نیست.", "The font file cannot be read."); map("ذخیرهٔ فونت انجام نشد.", "The font could not be saved.");
        map("هر روز ساعت ", "Every day at "); map("نمرهٔ نهایی روز", "Final daily score");
    }

    private AppSettings() {}
    private static void map(String fa, String en) { EN.put(fa, en); }
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    public static boolean isEnglish(Context c) { return "en".equals(prefs(c).getString(KEY_LANGUAGE, "fa")); }
    public static void setEnglish(Context c, boolean english) { prefs(c).edit().putString(KEY_LANGUAGE, english ? "en" : "fa").apply(); }
    public static String tr(Context c, String value) { return isEnglish(c) ? EN.getOrDefault(value, value) : value; }
    public static String digits(Context c, String value) {
        if (!isEnglish(c)) return value;
        String fa="۰۱۲۳۴۵۶۷۸۹", en="0123456789"; StringBuilder b=new StringBuilder(value.length());
        for(int i=0;i<value.length();i++){char ch=value.charAt(i);int ix=fa.indexOf(ch);b.append(ix>=0?en.charAt(ix):ch);} return b.toString();
    }
    public static String formatScore(Context c, double score) {
        String s=String.format(Locale.US,"%.1f",score);
        if (!isEnglish(c)) s=s.replace('.', '٫');
        return digits(c, s);
    }

    public static Typeface typeface(Context c) {
        if (cachedTypeface != null) return cachedTypeface;
        File file = new File(c.getFilesDir(), FONT_FILE);
        try { if (file.isFile() && file.length() > 0) cachedTypeface = Typeface.createFromFile(file); }
        catch (Exception ignored) { cachedTypeface = null; }
        if (cachedTypeface == null) {
            try { cachedTypeface = Typeface.createFromAsset(c.getAssets(), "fonts/yekan.ttf"); }
            catch (Exception ignored) { cachedTypeface = null; }
        }
        if (cachedTypeface == null) cachedTypeface = Typeface.create("sans-serif", Typeface.NORMAL);
        return cachedTypeface;
    }
    public static void resetTypeface() {
        cachedTypeface = null;
    }
    public static String fontFileName() { return FONT_FILE; }

    public static Palette palette(Context c) {
        String theme = prefs(c).getString(KEY_THEME, "blue");
        if ("custom".equals(theme)) {
            int bg = parse(prefs(c).getString(KEY_CUSTOM_BG, "#EFF5FD"), Color.rgb(239,245,253));
            int primary = parse(prefs(c).getString(KEY_CUSTOM_PRIMARY, "#0C4D9F"), Color.rgb(12,77,159));
            int accent = parse(prefs(c).getString(KEY_CUSTOM_ACCENT, "#009691"), Color.rgb(0,150,145));
            return new Palette(bg, Color.WHITE, Color.rgb(15,39,75), Color.rgb(94,119,153), primary, blend(primary, Color.WHITE, .86f), accent, theme);
        }
        switch (theme) {
            case "mint": return new Palette(Color.rgb(239,248,245), Color.WHITE, Color.rgb(28,55,48), Color.rgb(100,132,121), Color.rgb(42,119,98), Color.rgb(220,241,233), Color.rgb(33,151,124), theme);
            case "sand": return new Palette(Color.rgb(249,245,237), Color.WHITE, Color.rgb(65,51,35), Color.rgb(139,119,93), Color.rgb(139,104,61), Color.rgb(241,230,210), Color.rgb(177,133,68), theme);
            case "lavender": return new Palette(Color.rgb(246,243,251), Color.WHITE, Color.rgb(49,39,72), Color.rgb(123,111,151), Color.rgb(100,79,155), Color.rgb(232,224,247), Color.rgb(139,111,198), theme);
            case "graphite": return new Palette(Color.rgb(242,244,246), Color.WHITE, Color.rgb(38,45,53), Color.rgb(108,118,128), Color.rgb(76,91,108), Color.rgb(225,230,235), Color.rgb(82,132,146), theme);
            default: return new Palette(Color.rgb(239,245,253), Color.WHITE, Color.rgb(15,39,75), Color.rgb(94,119,153), Color.rgb(12,77,159), Color.rgb(222,236,255), Color.rgb(0,150,145), "blue");
        }
    }
    public static void setTheme(Context c, String theme) { prefs(c).edit().putString(KEY_THEME, theme).apply(); }
    public static void setCustomPalette(Context c, String bg, String primary, String accent) {
        prefs(c).edit().putString(KEY_THEME,"custom").putString(KEY_CUSTOM_BG,bg).putString(KEY_CUSTOM_PRIMARY,primary).putString(KEY_CUSTOM_ACCENT,accent).apply();
    }
    private static int parse(String s, int fallback) { try { return Color.parseColor(s); } catch(Exception e) { return fallback; } }
    private static int blend(int a,int b,float ratio){float ir=1f-ratio;return Color.rgb((int)(Color.red(a)*ir+Color.red(b)*ratio),(int)(Color.green(a)*ir+Color.green(b)*ratio),(int)(Color.blue(a)*ir+Color.blue(b)*ratio));}

    public static final class Palette {
        public final int bg, white, ink, muted, primary, pale, accent;
        public final String name;
        Palette(int bg,int white,int ink,int muted,int primary,int pale,int accent,String name){this.bg=bg;this.white=white;this.ink=ink;this.muted=muted;this.primary=primary;this.pale=pale;this.accent=accent;this.name=name;}
    }
}
