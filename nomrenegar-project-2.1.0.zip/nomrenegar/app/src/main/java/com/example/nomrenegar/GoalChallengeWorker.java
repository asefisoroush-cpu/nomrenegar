package com.example.nomrenegar;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.concurrent.TimeUnit;

/** Runs shortly after local midnight and closes the previous day's goal score. */
public final class GoalChallengeWorker extends Worker {
    private static final String UNIQUE = "nomrenegar_goal_challenge_daily";
    private static final String CHANNEL = "goal_challenge_results";

    public GoalChallengeWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        Context c=getApplicationContext();
        try {
            List<GoalChallengeStore.Evaluation> results=GoalChallengeStore.evaluateClosedDays(c,java.time.LocalDate.now());
            if(!results.isEmpty()) notifyResult(c,results.get(results.size()-1));
            scheduleNext(c);
            return Result.success();
        } catch(Exception e) {
            return Result.retry();
        }
    }

    public static void scheduleNext(Context c) {
        if(!GoalChallengeStore.isEnabled(c)) { cancel(c); return; }
        LocalDateTime now=LocalDateTime.now();
        LocalDateTime next=now.toLocalDate().plusDays(1).atTime(LocalTime.MIDNIGHT).plusMinutes(3);
        long delay=Math.max(TimeUnit.MINUTES.toMillis(1),Duration.between(now,next).toMillis());
        OneTimeWorkRequest request=new OneTimeWorkRequest.Builder(GoalChallengeWorker.class)
                .setInitialDelay(delay,TimeUnit.MILLISECONDS).build();
        WorkManager.getInstance(c).enqueueUniqueWork(UNIQUE,ExistingWorkPolicy.REPLACE,request);
    }

    public static void cancel(Context c) { WorkManager.getInstance(c).cancelUniqueWork(UNIQUE); }

    private static void notifyResult(Context c,GoalChallengeStore.Evaluation result) {
        try {
            NotificationManager manager=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
            if(manager==null)return;
            if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"نتیجهٔ چالش هدف‌گذاری",NotificationManager.IMPORTANCE_DEFAULT));
            Intent open=new Intent(c,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pending=PendingIntent.getActivity(c,9301,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            String score=AppSettings.formatScore(c,result.scoreTenths/10.0);
            String title=AppSettings.isEnglish(c)?"Your goal challenge result":"نتیجهٔ چالش هدف‌گذاری";
            String message=AppSettings.isEnglish(c)?"Yesterday's score: "+score:"نمرهٔ روز گذشته: "+score;
            Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
            b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(message).setAutoCancel(true).setContentIntent(pending);
            manager.notify(9301,b.build());
        } catch(Exception ignored) { /* Scoring is already persisted even when notifications are unavailable. */ }
    }
}
