package com.example.nomrenegar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Color;
import android.view.View;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Minimal native canvas line chart. Unrecorded days are deliberately omitted (not zero-filled). */
public final class ScoreChartView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Point> points=new ArrayList<>();
    private int ink=Color.rgb(83,111,150), grid=Color.rgb(225,234,247), blue=Color.rgb(15,126,219), teal=Color.rgb(6,158,151), muted=Color.rgb(111,132,162);
    public ScoreChartView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setPalette(int mutedColor,int lineColor,int pointColor,int gridColor){muted=mutedColor;blue=lineColor;teal=pointColor;grid=gridColor;invalidate();}
    public void setScores(Map<LocalDate,Integer> scores,LocalDate start,LocalDate end){
        points=new ArrayList<>(); long span=Math.max(1,java.time.temporal.ChronoUnit.DAYS.between(start,end));
        for(Map.Entry<LocalDate,Integer> e:scores.entrySet()) if(!e.getKey().isBefore(start)&&!e.getKey().isAfter(end)) {
            float x=(float)java.time.temporal.ChronoUnit.DAYS.between(start,e.getKey())/span;
            points.add(new Point(x,e.getValue()/10f,e.getKey()));
        }
        points.sort((a,b)->a.date.compareTo(b.date)); invalidate();
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas); paint.setTypeface(AppSettings.typeface(getContext())); float w=getWidth(),h=getHeight(); if(w<=0||h<=0)return;
        float left=dp(16),right=w-dp(12),top=dp(12),bottom=h-dp(28); if(bottom<=top)return;
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(grid);
        for(int i=0;i<=5;i++){float y=top+(bottom-top)*i/5f;canvas.drawLine(left,y,right,y,paint);}
        paint.setStyle(Paint.Style.FILL);paint.setTextSize(dp(10));paint.setColor(muted);
        for(int i=0;i<=5;i++){String s=AppSettings.digits(getContext(),String.valueOf(10-i*2));canvas.drawText(s,dp(1),top+(bottom-top)*i/5f+dp(4),paint);}
        if(points.isEmpty()){paint.setTextSize(dp(13));paint.setColor(muted);paint.setTextAlign(Paint.Align.CENTER);canvas.drawText(AppSettings.isEnglish(getContext())?"No scores recorded in this period":"برای این بازه هنوز نمره‌ای ثبت نشده",w/2f,(top+bottom)/2f,paint);paint.setTextAlign(Paint.Align.LEFT);return;}
        float chartLeft=left+dp(18),chartRight=right; paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(2.5f));paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);paint.setColor(blue);
        Path path=new Path(); boolean first=true;
        for(Point p:points){float x=chartLeft+(chartRight-chartLeft)*p.x;float y=bottom-(bottom-top)*p.score/10f;if(first){path.moveTo(x,y);first=false;}else path.lineTo(x,y);}
        canvas.drawPath(path,paint);
        paint.setStyle(Paint.Style.FILL);for(Point p:points){float x=chartLeft+(chartRight-chartLeft)*p.x;float y=bottom-(bottom-top)*p.score/10f;paint.setColor(Color.WHITE);canvas.drawCircle(x,y,dp(5),paint);paint.setColor(teal);canvas.drawCircle(x,y,dp(3),paint);}
        // Date labels are based on recorded observations only.
        paint.setColor(muted);paint.setTextSize(dp(9));paint.setTextAlign(Paint.Align.CENTER);
        int labels=Math.min(4,points.size()); for(int i=0;i<labels;i++){Point p=points.get(labels==1?0:i*(points.size()-1)/(labels-1));float x=chartLeft+(chartRight-chartLeft)*p.x;String s=AppSettings.digits(getContext(),String.format(java.util.Locale.US,"%02d/%02d",p.date.getMonthValue(),p.date.getDayOfMonth()));canvas.drawText(s,x,bottom+dp(18),paint);}
        paint.setTextAlign(Paint.Align.LEFT);
    }
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    private static final class Point{final float x,score;final LocalDate date;Point(float x,float s,LocalDate d){this.x=x;score=s;date=d;}}
}
