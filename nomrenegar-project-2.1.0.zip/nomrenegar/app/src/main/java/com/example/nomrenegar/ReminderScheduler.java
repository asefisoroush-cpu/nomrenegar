package com.example.nomrenegar;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;

public final class ReminderScheduler {
    public static final String CHANNEL_ID = "daily_score_reminder";
    private static final String PREFS = "reminder_settings_v1";
    private static final String KEY_HOUR = "hour";
    private static final String KEY_MINUTE = "minute";

    private ReminderScheduler() {}

    public static int getHour(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_HOUR, 21);
    }

    public static int getMinute(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_MINUTE, 0);
    }

    public static void saveTime(Context context, int hour, int minute) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putInt(KEY_HOUR, Math.max(0, Math.min(23, hour)))
                .putInt(KEY_MINUTE, Math.max(0, Math.min(59, minute)))
                .apply();
        schedule(context);
    }

    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "یادآور نمرهٔ روزانه", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("یادآوری روزانه برای ثبت نمره");
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    public static boolean canSchedulePrecisely(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return manager != null && manager.canScheduleExactAlarms();
    }

    public static Intent exactAlarmSettingsIntent(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + context.getPackageName()));
        }
        return new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + context.getPackageName()));
    }

    public static void schedule(Context context) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;

        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, 4201, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, getHour(context));
        next.set(Calendar.MINUTE, getMinute(context));
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (!next.after(Calendar.getInstance())) next.add(Calendar.DAY_OF_YEAR, 1);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && canSchedulePrecisely(context)) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                        next.getTimeInMillis(), pendingIntent);
            } else {
                // Fallback works without special exact-alarm access, but Android may delay it.
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                        next.getTimeInMillis(), pendingIntent);
            }
        } catch (SecurityException ignored) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                    next.getTimeInMillis(), pendingIntent);
        }
    }
}
