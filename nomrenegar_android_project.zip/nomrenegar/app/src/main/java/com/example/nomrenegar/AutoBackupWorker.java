package com.example.nomrenegar;

import android.content.Context;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Runs once per day when enabled and network access is available. */
public final class AutoBackupWorker extends Worker {
    public AutoBackupWorker(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);}
    @NonNull @Override public Result doWork(){
        Context c=getApplicationContext();
        if(!DriveBackupManager.autoEnabled(c)||!DriveBackupManager.connected(c))return Result.success();
        try{DriveBackupManager.uploadAuto(c,DriveBackupManager.account(c));return Result.success();}
        catch(Exception e){Log.e("NomreNegarBackup","Daily Google Drive backup failed",e);return Result.retry();}
    }
}
