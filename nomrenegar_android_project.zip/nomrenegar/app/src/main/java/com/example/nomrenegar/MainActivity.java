package com.example.nomrenegar;

import android.Manifest;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.time.temporal.TemporalAdjusters;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(239,245,253), WHITE=Color.WHITE, INK=Color.rgb(15,39,75), MUTED=Color.rgb(94,119,153), PRIMARY=Color.rgb(12,77,159), PALE=Color.rgb(222,236,255), TEAL=Color.rgb(0,150,145), ORANGE=Color.rgb(243,151,43);
    private static final int CREATE_BACKUP=8101, OPEN_BACKUP=8102;
    private String currentPage="home";
    private char[] pendingBackupPassword;
    private Uri exportedUri;
    private YearMonth calendarMonth=YearMonth.now();
    private int rangeMode=0, chartIndex=0;
    private TextView recentChoice, calendarChoice, chartTitle, averageValue, chartCount, pageIndicator;
    private ScoreChartView chartView;
    private LinearLayout chartCard;

    @Override protected void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);ReminderScheduler.createNotificationChannel(this);ReminderScheduler.schedule(this);DriveBackupManager.scheduleAuto(this);showHome();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7001);}
    @Override protected void onResume(){super.onResume();ReminderScheduler.schedule(this);DriveBackupManager.scheduleAuto(this);}
    @Override public void onBackPressed(){if(!"home".equals(currentPage))showHome();else super.onBackPressed();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable rounded(int color,float radius){GradientDrawable s=new GradientDrawable();s.setColor(color);s.setCornerRadius(dp(radius));return s;}
    private GradientDrawable gradient(int c1,int c2,float radius){GradientDrawable s=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{c1,c2});s.setCornerRadius(dp(radius));return s;}
    private TextView text(String value,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setTextDirection(View.TEXT_DIRECTION_RTL);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setTextSize(14);b.setTextColor(WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(rounded(PRIMARY,15));b.setMinHeight(dp(44));return b;}
    private Button lightButton(String label){Button b=button(label);b.setTextColor(PRIMARY);b.setBackground(rounded(PALE,15));return b;}

    private void showHome(){
        currentPage="home";
        LinearLayout root=vertical();root.setBackgroundColor(BG);
        LinearLayout top=horizontal();top.setPadding(dp(18),dp(8),dp(18),dp(8));
        TextView menu=text("⋮",31,PRIMARY,true);menu.setGravity(Gravity.CENTER);menu.setBackground(rounded(WHITE,14));menu.setElevation(dp(1));menu.setOnClickListener(v->showMenu());top.addView(menu,new LinearLayout.LayoutParams(dp(48),dp(44)));
        View spacer=new View(this);top.addView(spacer,new LinearLayout.LayoutParams(0,1,1));
        LinearLayout titles=vertical();TextView h=text("نمره‌نگار",20,INK,true);TextView sub=text("ثبت روزانه و مرور روند",11,MUTED,false);titles.addView(h);titles.addView(sub);titles.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);top.addView(titles);root.addView(top,new LinearLayout.LayoutParams(-1,dp(62)));

        LinearLayout controls=horizontal();controls.setPadding(dp(18),dp(4),dp(18),dp(8));
        recentChoice=choiceButton("اخیر",rangeMode==0);calendarChoice=choiceButton("تقویمی",rangeMode==1);
        controls.addView(recentChoice,new LinearLayout.LayoutParams(0,dp(42),1));View gap=new View(this);controls.addView(gap,new LinearLayout.LayoutParams(dp(8),1));controls.addView(calendarChoice,new LinearLayout.LayoutParams(0,dp(42),1));
        recentChoice.setOnClickListener(v->{rangeMode=0;chartIndex=0;refreshHomeChart();});calendarChoice.setOnClickListener(v->{rangeMode=1;chartIndex=0;refreshHomeChart();});root.addView(controls);

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(false);LinearLayout body=vertical();body.setPadding(dp(18),dp(2),dp(18),dp(10));scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        chartCard=vertical();chartCard.setPadding(dp(15),dp(10),dp(15),dp(10));chartCard.setBackground(rounded(WHITE,22));chartCard.setElevation(dp(2));
        LinearLayout heading=horizontal();chartTitle=text("",16,INK,true);heading.addView(chartTitle,new LinearLayout.LayoutParams(0,dp(34),1));pageIndicator=text("۱ از ۳",11,MUTED,false);pageIndicator.setGravity(Gravity.CENTER);heading.addView(pageIndicator,new LinearLayout.LayoutParams(dp(62),dp(30)));chartCard.addView(heading);
        chartView=new ScoreChartView(this);chartCard.addView(chartView,new LinearLayout.LayoutParams(-1,dp(230)));
        LinearLayout nav=horizontal();Button prev=lightButton("‹ قبلی"),next=lightButton("بعدی ›");nav.addView(prev,new LinearLayout.LayoutParams(0,dp(42),1));View navGap=new View(this);nav.addView(navGap,new LinearLayout.LayoutParams(dp(10),1));nav.addView(next,new LinearLayout.LayoutParams(0,dp(42),1));chartCard.addView(nav);prev.setOnClickListener(v->moveChart(-1));next.setOnClickListener(v->moveChart(1));
        final float[] touchX={0};chartView.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){touchX[0]=e.getX();return true;}if(e.getAction()==MotionEvent.ACTION_UP){float delta=e.getX()-touchX[0];if(Math.abs(delta)>dp(45))moveChart(delta>0?-1:1);return true;}return true;});
        body.addView(chartCard,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout avg=horizontal();avg.setPadding(dp(5),dp(6),dp(5),dp(2));TextView avgLabel=text("میانگین این بازه",13,MUTED,false);avg.addView(avgLabel,new LinearLayout.LayoutParams(0,dp(39),1));averageValue=text("—",23,TEAL,true);averageValue.setGravity(Gravity.CENTER);avg.addView(averageValue,new LinearLayout.LayoutParams(dp(100),dp(39)));body.addView(avg);
        chartCount=text("",11,MUTED,false);chartCount.setGravity(Gravity.CENTER);body.addView(chartCount,new LinearLayout.LayoutParams(-1,dp(25)));
        TextView note=text("فقط روزهای ثبت‌شده در نمودار و میانگین حساب می‌شوند.",11,MUTED,false);note.setGravity(Gravity.CENTER);body.addView(note,new LinearLayout.LayoutParams(-1,dp(28)));

        FrameLayout circleArea=new FrameLayout(this);circleArea.setClipChildren(false);circleArea.setClipToPadding(false);int areaHeight=dp(174);circleArea.setLayoutParams(new LinearLayout.LayoutParams(-1,areaHeight));
        View circle=new View(this);circle.setBackground(gradient(Color.rgb(12,50,107),Color.rgb(7,112,180),dp(300)));FrameLayout.LayoutParams circleLp=new FrameLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels+dp(32),getResources().getDisplayMetrics().widthPixels+dp(32),Gravity.TOP|Gravity.CENTER_HORIZONTAL);circle.setElevation(dp(1));circleArea.addView(circle,circleLp);
        TextView register=text("ثبت امروز",16,WHITE,true);register.setGravity(Gravity.CENTER);register.setBackground(rounded(TEAL,24));register.setElevation(dp(4));FrameLayout.LayoutParams registerLp=new FrameLayout.LayoutParams(dp(220),dp(54),Gravity.TOP|Gravity.CENTER_HORIZONTAL);registerLp.topMargin=dp(25);circleArea.addView(register,registerLp);register.setOnClickListener(v->showScoreDialog());
        TextView todaysub=text("نمرهٔ امروز هنوز ثبت نشده",12,Color.rgb(221,236,252),false);todaysub.setGravity(Gravity.CENTER);FrameLayout.LayoutParams todayLp=new FrameLayout.LayoutParams(-1,dp(26),Gravity.TOP);todayLp.topMargin=dp(83);circleArea.addView(todaysub,todayLp);
        body.addView(circleArea,new LinearLayout.LayoutParams(-1,areaHeight));circleArea.setTranslationY(dp(190));circleArea.setAlpha(.75f);circleArea.post(()->circleArea.animate().translationY(dp(15)).alpha(1f).setDuration(650).start());
        Integer saved=ScoreStore.getTenths(this,LocalDate.now());if(saved!=null){register.setText(ScoreStore.formatScore(saved/10.0));todaysub.setText("نمرهٔ امروز ثبت شده؛ برای ویرایش بزن.");}
        setContentView(root);refreshHomeChart();
    }

    private TextView choiceButton(String label,boolean selected){TextView t=text(label,15,selected?WHITE:PRIMARY,true);t.setGravity(Gravity.CENTER);t.setBackground(rounded(selected?PRIMARY:WHITE,14));t.setElevation(selected?dp(1):0);return t;}
    private void refreshHomeChart(){if(chartView==null||isFinishing())return;recentChoice.setBackground(rounded(rangeMode==0?PRIMARY:WHITE,14));recentChoice.setTextColor(rangeMode==0?WHITE:PRIMARY);calendarChoice.setBackground(rounded(rangeMode==1?PRIMARY:WHITE,14));calendarChoice.setTextColor(rangeMode==1?WHITE:PRIMARY);
        LocalDate today=LocalDate.now(),start,end;String title;int total;
        if(rangeMode==0){int[] sizes={7,30,365};String[] titles={"۷ روز اخیر","۳۰ روز اخیر","۳۶۵ روز اخیر"};total=sizes[chartIndex];start=today.minusDays(total-1L);end=today;title=titles[chartIndex];}
        else {if(chartIndex==0){start=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));end=start.plusDays(6);title="هفتهٔ جاری میلادی";}else if(chartIndex==1){YearMonth m=YearMonth.from(today);start=m.atDay(1);end=m.atEndOfMonth();title="ماه جاری میلادی";}else{start=LocalDate.of(today.getYear(),1,1);end=LocalDate.of(today.getYear(),12,31);title="سال جاری میلادی";}total=(int)(java.time.temporal.ChronoUnit.DAYS.between(start,end)+1);}
        chartTitle.setText(title);pageIndicator.setText(ScoreStore.toPersianDigits((chartIndex+1)+" از ۳"));Map<LocalDate,Integer> all=ScoreStore.getAllScores(this);chartView.setScores(all,start,end);ScoreStore.Average av=ScoreStore.averageForRange(this,start,end,total);averageValue.setText(av.value==null?"—":ScoreStore.formatScore(av.value));chartCount.setText(av.recordedDays==0?"هیچ نمره‌ای در این بازه ثبت نشده":"بر پایهٔ "+ScoreStore.toPersianDigits(String.valueOf(av.recordedDays))+" روز ثبت‌شده از "+ScoreStore.toPersianDigits(String.valueOf(total))+" روز");}
    private void moveChart(int amount){chartIndex=(chartIndex+amount+3)%3;refreshHomeChart();}

    private void showScoreDialog(){Integer saved=ScoreStore.getTenths(this,LocalDate.now());NumberPicker picker=new NumberPicker(this);picker.setMinValue(0);picker.setMaxValue(100);String[] vals=new String[101];for(int i=0;i<=100;i++)vals[i]=ScoreStore.formatScore(i/10.0);picker.setDisplayedValues(vals);picker.setWrapSelectorWheel(false);picker.setValue(saved==null?50:saved);LinearLayout panel=vertical();panel.setPadding(dp(16),dp(8),dp(16),0);TextView date=text("تاریخ میلادی: "+LocalDate.now(),13,MUTED,false);date.setGravity(Gravity.CENTER);panel.addView(date);panel.addView(picker,new LinearLayout.LayoutParams(-1,dp(190)));
        new AlertDialog.Builder(this).setTitle(saved==null?"ثبت نمرهٔ امروز":"ویرایش نمرهٔ امروز").setView(panel).setNegativeButton("لغو",null).setPositiveButton("ذخیره",(d,w)->{ScoreStore.saveScore(this,LocalDate.now(),picker.getValue());showHome();Toast.makeText(this,"نمره ذخیره شد.",Toast.LENGTH_SHORT).show();}).show();}

    private void showMenu(){
        final Dialog dialog=new Dialog(this);LinearLayout panel=vertical();panel.setPadding(dp(20),dp(18),dp(20),dp(14));panel.setBackground(rounded(Color.rgb(247,250,255),24));TextView heading=text("منو",20,INK,true);panel.addView(heading,new LinearLayout.LayoutParams(-1,dp(42)));
        addMenuItem(panel,"تنظیمات","اتصال ایمیل و Google Drive",()->{dialog.dismiss();showSettingsPage();});addMenuItem(panel,"تقویم","نمره‌های روزانه در تقویم میلادی",()->{dialog.dismiss();showCalendarPage();});addMenuItem(panel,"پشتیبان‌گیری","ساخت و بازیابی فایل پشتیبان",()->{dialog.dismiss();showBackupPage();});
        TextView close=text("بستن",14,PRIMARY,true);close.setGravity(Gravity.CENTER);close.setBackground(rounded(PALE,12));panel.addView(close,new LinearLayout.LayoutParams(-1,dp(42)));close.setOnClickListener(v->dialog.dismiss());
        dialog.setContentView(panel);Window win=dialog.getWindow();if(win!=null){win.setBackgroundDrawableResource(android.R.color.transparent);WindowManager.LayoutParams lp=new WindowManager.LayoutParams();lp.copyFrom(win.getAttributes());lp.width=-1;lp.height=getResources().getDisplayMetrics().heightPixels/2;lp.gravity=Gravity.TOP;lp.dimAmount=.22f;win.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);win.setAttributes(lp);}dialog.show();if(win!=null){win.setLayout(-1,getResources().getDisplayMetrics().heightPixels/2);win.setGravity(Gravity.TOP);}
    }
    private void addMenuItem(LinearLayout panel,String title,String detail,Runnable run){LinearLayout item=vertical();item.setPadding(dp(15),dp(9),dp(15),dp(8));item.setBackground(rounded(WHITE,15));item.setElevation(dp(1));item.addView(text(title,16,INK,true));item.addView(text(detail,11,MUTED,false));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(68));lp.topMargin=dp(7);panel.addView(item,lp);item.setOnClickListener(v->run.run());}

    private LinearLayout makeSubPage(String title,String subtitle){currentPage="subpage";LinearLayout root=vertical();root.setBackgroundColor(BG);LinearLayout top=horizontal();top.setPadding(dp(16),dp(8),dp(16),dp(8));TextView back=text("‹",32,PRIMARY,true);back.setGravity(Gravity.CENTER);back.setBackground(rounded(WHITE,14));back.setOnClickListener(v->showHome());top.addView(back,new LinearLayout.LayoutParams(dp(44),dp(42)));LinearLayout hs=vertical();hs.setPadding(dp(12),0,0,0);hs.addView(text(title,21,INK,true));hs.addView(text(subtitle,11,MUTED,false));top.addView(hs,new LinearLayout.LayoutParams(0,dp(50),1));TextView menu=text("⋮",28,PRIMARY,true);menu.setGravity(Gravity.CENTER);menu.setBackground(rounded(WHITE,14));menu.setOnClickListener(v->showMenu());top.addView(menu,new LinearLayout.LayoutParams(dp(44),dp(42)));root.addView(top,new LinearLayout.LayoutParams(-1,dp(62)));ScrollView scroll=new ScrollView(this);LinearLayout body=vertical();body.setPadding(dp(18),dp(10),dp(18),dp(22));scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);return body;}
    private View actionCard(String title,String sub,String symbol,Runnable action){LinearLayout card=vertical();card.setPadding(dp(16),dp(13),dp(16),dp(12));card.setBackground(rounded(WHITE,19));card.setElevation(dp(1));TextView icon=text(symbol,17,PRIMARY,true);icon.setGravity(Gravity.CENTER);icon.setBackground(rounded(PALE,30));card.addView(icon,new LinearLayout.LayoutParams(dp(34),dp(34)));TextView t=text(title,16,INK,true);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(-1,dp(34));tlp.topMargin=dp(4);card.addView(t,tlp);card.addView(text(sub,12,MUTED,false));card.setOnClickListener(v->action.run());return card;}

    private void showSettingsPage(){LinearLayout body=makeSubPage("تنظیمات","حساب، همگام‌سازی و یادآور روزانه");
        LinearLayout account=vertical();account.setPadding(dp(16),dp(15),dp(16),dp(15));account.setBackground(rounded(WHITE,20));TextView title=text("اتصال ایمیل و Google Drive",16,INK,true);account.addView(title,new LinearLayout.LayoutParams(-1,dp(34)));String email=DriveBackupManager.account(this);TextView state=text(email==null?"حسابی متصل نیست":"حساب متصل: "+email,12,email==null?MUTED:TEAL,false);state.setTextDirection(View.TEXT_DIRECTION_LTR);account.addView(state,new LinearLayout.LayoutParams(-1,dp(34)));Button connect=button(email==null?"اتصال حساب گوگل":"تغییر حساب متصل");LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,dp(48));clp.topMargin=dp(8);account.addView(connect,clp);connect.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.GET_ACCOUNTS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.GET_ACCOUNTS},7010);return;}DriveBackupManager.chooseGoogleAccount(this);});body.addView(account);
        LinearLayout auto=vertical();auto.setPadding(dp(16),dp(15),dp(16),dp(14));auto.setBackground(rounded(WHITE,20));LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,-2);alp.topMargin=dp(12);body.addView(auto,alp);auto.addView(text("پشتیبان گیری خودکار",17,INK,true),new LinearLayout.LayoutParams(-1,dp(35)));String autoState=DriveBackupManager.autoEnabled(this)?"وضعیت: روشن":"وضعیت: خاموش";TextView as=text(autoState,12,DriveBackupManager.autoEnabled(this)?TEAL:MUTED,false);auto.addView(as,new LinearLayout.LayoutParams(-1,dp(28)));Button toggle=lightButton(DriveBackupManager.autoEnabled(this)?"خاموش کردن پشتیبان‌گیری خودکار":"روشن کردن پشتیبان‌گیری خودکار");LinearLayout.LayoutParams toggleLp=new LinearLayout.LayoutParams(-1,dp(48));toggleLp.topMargin=dp(5);auto.addView(toggle,toggleLp);toggle.setOnClickListener(v->{if(!DriveBackupManager.connected(this)){new AlertDialog.Builder(this).setTitle("ابتدا حساب را متصل کن").setMessage("برای پشتیبان‌گیری روزانه باید ابتدا یک حساب گوگل را انتخاب و اجازهٔ دسترسی Drive را تأیید کنی.").setNegativeButton("بعداً",null).setPositiveButton("اتصال حساب",(d,w)->DriveBackupManager.chooseGoogleAccount(this)).show();return;}boolean enabled=!DriveBackupManager.autoEnabled(this);DriveBackupManager.setAutoEnabled(this,enabled);DriveBackupManager.scheduleAuto(this);if(enabled)DriveBackupManager.runBackupNow(this);showSettingsPage();Toast.makeText(this,enabled?"پشتیبان‌گیری خودکار فعال شد.":"پشتیبان‌گیری خودکار خاموش شد.",Toast.LENGTH_SHORT).show();});
        TextView info=text("نسخهٔ خودکار در پوشهٔ خصوصی appDataFolder گوگل‌درایو ذخیره می‌شود. اجرای آن به دسترسی معتبر گوگل و فعال بودن Google Drive API برای حساب وابسته است.",12,MUTED,false);info.setPadding(dp(4),dp(14),dp(4),0);body.addView(info);
        LinearLayout reminder=vertical();reminder.setPadding(dp(16),dp(14),dp(16),dp(14));reminder.setBackground(rounded(WHITE,18));LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,-2);rlp.topMargin=dp(12);body.addView(reminder,rlp);reminder.addView(text("یادآور روزانه",15,INK,true));reminder.addView(text("هر روز ساعت "+timeText(ReminderScheduler.getHour(this),ReminderScheduler.getMinute(this)),13,PRIMARY,true));reminder.setOnClickListener(v->chooseReminderTime());
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==7010&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)DriveBackupManager.chooseGoogleAccount(this);}

    private void showCalendarPage(){LinearLayout body=makeSubPage("تقویم","تقویم میلادی؛ روزهای بدون نمره خالی می‌مانند.");LinearLayout nav=horizontal();Button prev=lightButton("‹ ماه قبل"),next=lightButton("ماه بعد ›");nav.addView(prev,new LinearLayout.LayoutParams(0,dp(44),1));View gap=new View(this);nav.addView(gap,new LinearLayout.LayoutParams(dp(8),1));nav.addView(next,new LinearLayout.LayoutParams(0,dp(44),1));body.addView(nav);TextView label=text(calendarMonth.getMonth().getDisplayName(TextStyle.FULL,Locale.ENGLISH)+" "+calendarMonth.getYear(),18,INK,true);label.setGravity(Gravity.CENTER);body.addView(label,new LinearLayout.LayoutParams(-1,dp(48)));
        GridLayout grid=new GridLayout(this);grid.setColumnCount(7);grid.setBackground(rounded(WHITE,18));grid.setPadding(dp(5),dp(7),dp(5),dp(7));String[] weekdays={"Mon","Tue","Wed","Thu","Fri","Sat","Sun"};for(String day:weekdays){TextView t=text(day,10,MUTED,true);t.setGravity(Gravity.CENTER);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(28);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(t,lp);}
        int offset=calendarMonth.atDay(1).getDayOfWeek().getValue()-1;for(int i=0;i<offset;i++){TextView blank=text("",10,MUTED,false);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(56);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(blank,lp);}
        for(int day=1;day<=calendarMonth.lengthOfMonth();day++){LocalDate date=calendarMonth.atDay(day);Integer score=ScoreStore.getTenths(this,date);TextView cell=text(String.valueOf(day)+(score==null?"":"\n"+ScoreStore.formatScore(score/10.0)),score==null?12:10,score==null?MUTED:PRIMARY,score!=null);cell.setGravity(Gravity.CENTER);cell.setBackground(rounded(score==null?BG:PALE,8));GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(56);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);lp.setMargins(dp(2),dp(2),dp(2),dp(2));grid.addView(cell,lp);cell.setOnClickListener(v->{if(score==null){new AlertDialog.Builder(this).setMessage("برای "+date+" نمره‌ای ثبت نشده است.").setPositiveButton("باشه",null).show();}else new AlertDialog.Builder(this).setTitle(date.toString()).setMessage("نمره: "+ScoreStore.formatScore(score/10.0)).setNegativeButton("بستن",null).setPositiveButton("ویرایش",(d,w)->showScoreForDate(date)).show();});}
        LinearLayout.LayoutParams glp=new LinearLayout.LayoutParams(-1,-2);body.addView(grid,glp);prev.setOnClickListener(v->{calendarMonth=calendarMonth.minusMonths(1);showCalendarPage();});next.setOnClickListener(v->{calendarMonth=calendarMonth.plusMonths(1);showCalendarPage();});
    }
    private void showScoreForDate(LocalDate date){Integer saved=ScoreStore.getTenths(this,date);NumberPicker picker=new NumberPicker(this);picker.setMinValue(0);picker.setMaxValue(100);String[] vals=new String[101];for(int i=0;i<=100;i++)vals[i]=ScoreStore.formatScore(i/10.0);picker.setDisplayedValues(vals);picker.setValue(saved==null?50:saved);new AlertDialog.Builder(this).setTitle("نمرهٔ "+date).setView(picker).setNegativeButton("لغو",null).setPositiveButton("ذخیره",(d,w)->{ScoreStore.saveScore(this,date,picker.getValue());showCalendarPage();}).show();}

    private void showBackupPage(){LinearLayout body=makeSubPage("پشتیبان‌گیری","فایل رمزدار بساز یا نمره‌ها را بازیابی کن.");body.addView(actionCard("ساخت فایل پشتیبان رمزدار","تمام نمره‌های تاریخ‌دار در یک فایل رمزگذاری می‌شوند.","↓",this::askExportPassword),new LinearLayout.LayoutParams(-1,dp(130)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(130));lp.topMargin=dp(12);body.addView(actionCard("بازیابی از فایل","فایل پشتیبان را انتخاب کن و رمز آن را وارد کن.","↑",this::askImportPassword),lp);TextView warning=text("رمزگذاری با AES-GCM انجام می‌شود. رمز را جداگانه نگه دار؛ بدون آن فایل بازیابی نمی‌شود. ورود اطلاعات، تاریخ‌های داخل فایل را جایگزین می‌کند و تاریخ‌های دیگر را دست‌نخورده می‌گذارد.",12,MUTED,false);warning.setPadding(dp(4),dp(14),dp(4),0);body.addView(warning);}
    private void askExportPassword(){EditText input=new EditText(this);input.setHint("رمز فایل (حداقل ۸ نویسه)");input.setInputType(129);new AlertDialog.Builder(this).setTitle("رمزگذاری فایل").setView(input).setNegativeButton("لغو",null).setPositiveButton("ادامه",(d,w)->{String p=input.getText().toString();if(p.length()<8){Toast.makeText(this,"رمز باید حداقل ۸ نویسه باشد.",Toast.LENGTH_LONG).show();return;}pendingBackupPassword=p.toCharArray();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/octet-stream");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_TITLE,"nomrenegar-backup.nrb");startActivityForResult(i,CREATE_BACKUP);}).show();}
    private void askImportPassword(){EditText input=new EditText(this);input.setHint("رمز فایل");input.setInputType(129);new AlertDialog.Builder(this).setTitle("بازیابی پشتیبان").setView(input).setNegativeButton("لغو",null).setPositiveButton("انتخاب فایل",(d,w)->{pendingBackupPassword=input.getText().toString().toCharArray();Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,OPEN_BACKUP);}).show();}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==DriveBackupManager.AUTH_REQUEST_CODE){
            if(resultCode!=RESULT_OK){DriveBackupManager.clearPending(this);return;}
            if(DriveBackupManager.pendingAccount(this)!=null){DriveBackupManager.handleAuthResult(this,data,ok->{runOnUiThread(()->{if(ok){DriveBackupManager.scheduleAuto(this);Toast.makeText(this,"حساب گوگل متصل شد.",Toast.LENGTH_LONG).show();showSettingsPage();}else Toast.makeText(this,"اتصال انجام نشد؛ مطمئن شو Google Drive API و دسترسی حساب فعال‌اند.",Toast.LENGTH_LONG).show();});});}
            else {String email=data==null?null:data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);if(email!=null)DriveBackupManager.connect(this,email,ok->{if(ok)runOnUiThread(()->{Toast.makeText(this,"حساب گوگل متصل شد.",Toast.LENGTH_LONG).show();showSettingsPage();});});}return;
        }
        if(resultCode!=RESULT_OK||data==null||data.getData()==null){pendingBackupPassword=null;return;}Uri uri=data.getData();
        try{if(requestCode==CREATE_BACKUP&&pendingBackupPassword!=null){try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new java.io.IOException("امکان نوشتن فایل وجود ندارد.");EncryptedBackup.write(this,out,pendingBackupPassword);}exportedUri=uri;new AlertDialog.Builder(this).setTitle("پشتیبان ذخیره شد").setMessage("فایل رمزگذاری‌شده ذخیره شد. می‌خواهی آن را ارسال کنی؟").setNegativeButton("بعداً",null).setPositiveButton("ارسال فایل",(d,w)->shareBackup(uri)).show();}else if(requestCode==OPEN_BACKUP&&pendingBackupPassword!=null){try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new java.io.IOException("امکان خواندن فایل وجود ندارد.");EncryptedBackup.read(this,in,pendingBackupPassword);}Toast.makeText(this,"نمره‌ها بازیابی شدند.",Toast.LENGTH_LONG).show();showHome();}}catch(Exception ex){Toast.makeText(this,"عملیات ناموفق بود؛ رمز یا فایل را بررسی کن.",Toast.LENGTH_LONG).show();}finally{pendingBackupPassword=null;}
    }
    private void shareBackup(Uri uri){try{Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/octet-stream");send.putExtra(Intent.EXTRA_STREAM,uri);send.setClipData(ClipData.newUri(getContentResolver(),"نمره‌نگار - فایل پشتیبان",uri));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"ارسال فایل پشتیبان"));}catch(Exception e){Toast.makeText(this,"امکان باز کردن بخش ارسال فایل وجود ندارد.",Toast.LENGTH_LONG).show();}}

    private void chooseReminderTime(){int hour=ReminderScheduler.getHour(this),minute=ReminderScheduler.getMinute(this);TimePickerDialog dialog=new TimePickerDialog(this,(view,h,m)->{ReminderScheduler.saveTime(this,h,m);if("home".equals(currentPage))showHome();if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S&&!ReminderScheduler.canSchedulePrecisely(this))new AlertDialog.Builder(this).setTitle("اجازهٔ اعلان سرِ ساعت").setMessage("برای اجرای دقیق در ساعت انتخاب‌شده، دسترسی آلارم دقیق را فعال کن؛ در غیر این صورت اعلان ممکن است با تأخیر برسد.").setNegativeButton("بعداً",null).setPositiveButton("رفتن به تنظیمات",(d,w)->{try{startActivity(ReminderScheduler.exactAlarmSettingsIntent(this));}catch(Exception ex){Toast.makeText(this,"تنظیمات آلارم در این دستگاه در دسترس نیست.",Toast.LENGTH_LONG).show();}}).show();},hour,minute,true);dialog.setTitle("ساعت یادآور روزانه");dialog.show();}
    private String timeText(int h,int m){return ScoreStore.toPersianDigits(String.format(Locale.US,"%02d:%02d",h,m));}
}
