package com.example.nomrenegar;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(235, 243, 253);
    private static final int WHITE = Color.WHITE;
    private static final int INK = Color.rgb(16, 42, 78);
    private static final int MUTED = Color.rgb(91, 112, 140);
    private static final int PRIMARY = Color.rgb(18, 91, 171);
    private static final int PALE = Color.rgb(224, 239, 255);
    private static final int DISABLED = Color.rgb(232, 235, 237);
    private String currentPage = "home";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        ReminderScheduler.createNotificationChannel(this);
        ReminderScheduler.schedule(this);
        showHome();

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7001);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ReminderScheduler.schedule(this);
    }

    @Override
    public void onBackPressed() {
        if (!"home".equals(currentPage)) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radiusDp));
        return shape;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        view.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return layout;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private LinearLayout makePage(String title, String subtitle, boolean backButton) {
        currentPage = backButton ? "subpage" : "home";
        LinearLayout root = vertical();
        root.setBackgroundColor(BG);

        LinearLayout header = vertical();
        header.setPadding(dp(20), dp(16), dp(20), dp(14));
        if (backButton) {
            TextView back = text("‹  بازگشت", 14, PRIMARY, true);
            back.setPadding(0, 0, 0, dp(10));
            back.setOnClickListener(v -> showHome());
            header.addView(back, new LinearLayout.LayoutParams(-1, dp(32)));
        }
        TextView menu = text("⋮", 30, PRIMARY, true);
        menu.setGravity(Gravity.CENTER);
        menu.setBackground(rounded(WHITE, 14));
        menu.setOnClickListener(v -> showMenu());
        LinearLayout.LayoutParams menuLp = new LinearLayout.LayoutParams(dp(46), dp(42));
        menuLp.bottomMargin = dp(8);
        header.addView(menu, menuLp);
        TextView heading = text(title, 25, INK, true);
        header.addView(heading, new LinearLayout.LayoutParams(-1, dp(40)));
        TextView sub = text(subtitle, 13, MUTED, false);
        header.addView(sub, new LinearLayout.LayoutParams(-1, dp(28)));
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        LinearLayout body = vertical();
        body.setPadding(dp(18), dp(4), dp(18), dp(26));
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        return body;
    }

    private void showHome() {
        LinearLayout body = makePage("نمره‌نگار", "روند روزانه‌ات را ثبت و دنبال کن", false);
        LocalDate today = LocalDate.now();
        Integer saved = ScoreStore.getTenths(this, today);
        LinearLayout hero = vertical();
        hero.setPadding(dp(20),dp(22),dp(20),dp(22));
        hero.setBackground(rounded(PRIMARY,28));
        TextView date=text(today.toString(),14,Color.rgb(220,235,255),false); date.setGravity(Gravity.CENTER);
        hero.addView(date,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView score=text(saved==null?"ثبت نمرهٔ امروز":ScoreStore.formatScore(saved/10.0)+"  ✎",32,WHITE,true);score.setGravity(Gravity.CENTER);
        hero.addView(score,new LinearLayout.LayoutParams(-1,dp(65)));
        score.setOnClickListener(v -> showScorePage());
        TextView hint=text(saved==null?"برای ثبت نمره بزن":"برای ویرایش نمره بزن",13,Color.WHITE,false);hint.setGravity(Gravity.CENTER);
        hero.addView(hint);
        body.addView(hero,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout stats=horizontal();
        addMiniAverage(stats,7,"هفته");
        addMiniAverage(stats,30,"ماه");
        addMiniAverage(stats,365,"سال");
        LinearLayout.LayoutParams st=new LinearLayout.LayoutParams(-1,dp(115));st.topMargin=dp(14);body.addView(stats,st);
        TextView calendar=text("تقویم نمره‌ها  ›",17,INK,true);calendar.setPadding(dp(16),dp(8),dp(16),dp(8));calendar.setBackground(rounded(WHITE,18));
        calendar.setOnClickListener(v->showCalendarPage());LinearLayout.LayoutParams cl=new LinearLayout.LayoutParams(-1,dp(58));cl.topMargin=dp(12);body.addView(calendar,cl);
        LinearLayout reminder=vertical();reminder.setPadding(dp(16),dp(12),dp(16),dp(12));reminder.setBackground(rounded(WHITE,18));
        reminder.addView(text("یادآور روزانه",15,INK,true));
        reminder.addView(text("هر روز ساعت "+timeText(ReminderScheduler.getHour(this),ReminderScheduler.getMinute(this))+" — برای تغییر بزن",13,PRIMARY,false));
        reminder.setOnClickListener(v->chooseReminderTime());LinearLayout.LayoutParams rl=new LinearLayout.LayoutParams(-1,-2);rl.topMargin=dp(12);body.addView(reminder,rl);
    }

    private void addMiniAverage(LinearLayout row,int days,String label){
        ScoreStore.Average a=ScoreStore.averageForLastDays(this,days);
        LinearLayout card=vertical();card.setGravity(Gravity.CENTER);card.setPadding(dp(5),dp(8),dp(5),dp(8));card.setBackground(rounded(WHITE,18));
        TextView val=text(a.value==null?"—":ScoreStore.formatScore(a.value),21,PRIMARY,true);val.setGravity(Gravity.CENTER);card.addView(val);
        TextView lab=text("میانگین "+label,12,MUTED,false);lab.setGravity(Gravity.CENTER);card.addView(lab);
        row.addView(card,new LinearLayout.LayoutParams(0,-1,1));
        View gap=new View(this);row.addView(gap,new LinearLayout.LayoutParams(dp(7),1));
    }

    private void showMenu(){
        String[] items={"تقویم","پشتیبان گیری","تنظیمات"};
        new AlertDialog.Builder(this).setTitle("منوی نمره‌نگار").setItems(items,(d,w)->{
            if(w==0)showCalendarPage(); else if(w==1)showBackupPage(); else showSettingsPage();
        }).show();
    }

    private void showCalendarPage(){
        LinearLayout body=makePage("تقویم","تقویم میلادی و نمرهٔ ثبت‌شده برای هر روز",true);
        java.time.YearMonth month=java.time.YearMonth.now();
        TextView title=text(month.toString(),20,PRIMARY,true);title.setGravity(Gravity.CENTER);
        body.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
        GridLayout grid=new GridLayout(this);grid.setColumnCount(7);grid.setBackground(rounded(WHITE,18));grid.setPadding(dp(5),dp(8),dp(5),dp(8));
        String[] names={"د","س","چ","پ","ج","ش","ی"};
        for(String n:names){TextView t=text(n,12,MUTED,true);t.setGravity(Gravity.CENTER);grid.addView(t,new GridLayout.LayoutParams());}
        int offset=month.atDay(1).getDayOfWeek().getValue()%7;
        for(int i=0;i<offset;i++){TextView blank=text("",12,MUTED,false);grid.addView(blank,new GridLayout.LayoutParams());}
        for(int day=1;day<=month.lengthOfMonth();day++){
            LocalDate date=month.atDay(day);Integer value=ScoreStore.getTenths(this,date);
            TextView cell=text(day+(value==null?"":"\n"+ScoreStore.formatScore(value/10.0)),value==null?13:11,value==null?INK:PRIMARY,value!=null);
            cell.setGravity(Gravity.CENTER);cell.setBackground(rounded(date.equals(LocalDate.now())?PALE:BG,10));
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(54);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);lp.setMargins(dp(2),dp(2),dp(2),dp(2));grid.addView(cell,lp);
            cell.setOnClickListener(v->new DatePickerDialog(this,(view,y,m,d)->showDateScore(LocalDate.of(y,m+1,d)),date.getYear(),date.getMonthValue()-1,date.getDayOfMonth()).show());
        }
        body.addView(grid,new LinearLayout.LayoutParams(-1,-2));
        body.addView(text("روزهای بدون نمره خالی می‌مانند و در میانگین‌ها حساب نمی‌شوند.",13,MUTED,false));
    }

    private void showDateScore(LocalDate date){
        Integer val=ScoreStore.getTenths(this,date);
        if(date.equals(LocalDate.now())){showScorePage();return;}
        new AlertDialog.Builder(this).setTitle(date.toString()).setMessage(val==null?"برای این روز نمره‌ای ثبت نشده است.":"نمره: "+ScoreStore.formatScore(val/10.0)).setPositiveButton("باشه",null).show();
    }

    private void showBackupPage(){
        LinearLayout body=makePage("پشتیبان گیری","فایل رمزگذاری‌شدهٔ نمره‌ها را ذخیره یا بازیابی کن",true);
        TextView info=text("فایل پشتیبان با رمز عبور رمزگذاری می‌شود. رمز را نگه دار؛ بدون آن بازیابی ممکن نیست.",14,MUTED,false);
        body.addView(info,new LinearLayout.LayoutParams(-1,dp(80)));
        Button export=button("ساخت فایل پشتیبان");body.addView(export,new LinearLayout.LayoutParams(-1,dp(54)));
        export.setOnClickListener(v->askBackupPassword(true));
        Button imp=button("بازیابی از فایل");LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(54));ip.topMargin=dp(12);body.addView(imp,ip);
        imp.setOnClickListener(v->askBackupPassword(false));
    }
    private void askBackupPassword(boolean export){
        EditText pass=new EditText(this);pass.setHint("رمز عبور (حداقل 6 کاراکتر)");pass.setInputType(129);
        new AlertDialog.Builder(this).setTitle(export?"رمز فایل پشتیبان":"رمز فایل پشتیبان").setView(pass)
          .setNegativeButton("لغو",null).setPositiveButton("ادامه",(d,w)->{
            String p=pass.getText().toString();if(p.length()<6){Toast.makeText(this,"رمز باید حداقل ۶ کاراکتر باشد.",Toast.LENGTH_LONG).show();return;}
            if(export)BackupManager.export(this,p);else BackupManager.importFile(this,p);
          }).show();
    }
    private void showSettingsPage(){
        LinearLayout body=makePage("تنظیمات","تنظیمات فعلی نمره‌نگار",true);
        TextView reminder=text("تغییر ساعت یادآور روزانه",16,PRIMARY,true);reminder.setBackground(rounded(WHITE,18));reminder.setPadding(dp(16),dp(12),dp(16),dp(12));
        reminder.setOnClickListener(v->chooseReminderTime());body.addView(reminder,new LinearLayout.LayoutParams(-1,dp(58)));
        body.addView(text("تقویم و ذخیره‌سازی بر اساس تاریخ میلادی گوشی انجام می‌شود.",13,MUTED,false));
    }

    private View sectionCard(String title, String subtitle, String numeral, boolean enabled, Runnable action) {
        LinearLayout card = vertical();
        card.setPadding(dp(14), dp(13), dp(14), dp(12));
        card.setBackground(rounded(enabled ? WHITE : DISABLED, 20));
        card.setElevation(enabled ? dp(2) : 0);
        TextView number = text(numeral, 13, enabled ? PRIMARY : MUTED, true);
        number.setGravity(Gravity.CENTER);
        number.setBackground(rounded(enabled ? PALE : Color.rgb(218, 222, 224), 30));
        card.addView(number, new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView titleView = text(title, 16, enabled ? INK : MUTED, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, dp(34));
        titleLp.topMargin = dp(6);
        card.addView(titleView, titleLp);
        TextView subView = text(subtitle, 11, MUTED, false);
        card.addView(subView, new LinearLayout.LayoutParams(-1, -2));
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> action.run());
        return card;
    }

    private void showScorePage() {
        LinearLayout body = makePage("ثبت نمره", "برای هر روز یک نمره از ۰ تا ۱۰ انتخاب کن.", true);
        LocalDate today = LocalDate.now();
        Integer saved = ScoreStore.getTenths(this, today);

        LinearLayout panel = vertical();
        panel.setPadding(dp(18), dp(18), dp(18), dp(18));
        panel.setBackground(rounded(WHITE, 22));
        TextView date = text("نمرهٔ امروز", 16, INK, true);
        date.setGravity(Gravity.CENTER);
        panel.addView(date, new LinearLayout.LayoutParams(-1, dp(32)));

        TextView current = text(saved == null ? "هنوز ثبت نشده" : "نمرهٔ ذخیره‌شده: " + ScoreStore.formatScore(saved / 10.0),
                13, saved == null ? MUTED : PRIMARY, saved != null);
        current.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams currentLp = new LinearLayout.LayoutParams(-1, dp(30));
        currentLp.topMargin = dp(4);
        panel.addView(current, currentLp);

        NumberPicker picker = new NumberPicker(this);
        picker.setMinValue(0);
        picker.setMaxValue(100);
        String[] values = new String[101];
        for (int i = 0; i <= 100; i++) values[i] = ScoreStore.formatScore(i / 10.0);
        picker.setDisplayedValues(values);
        picker.setWrapSelectorWheel(false);
        picker.setValue(saved == null ? 50 : saved);
        picker.setDescendantFocusability(NumberPicker.FOCUS_AFTER_DESCENDANTS);
        LinearLayout.LayoutParams pickerLp = new LinearLayout.LayoutParams(-1, dp(190));
        pickerLp.topMargin = dp(6);
        panel.addView(picker, pickerLp);

        TextView range = text("کمترین: ۰٫۰                       بیشترین: ۱۰٫۰", 12, MUTED, false);
        range.setGravity(Gravity.CENTER);
        panel.addView(range, new LinearLayout.LayoutParams(-1, dp(28)));

        Button save = button("ذخیرهٔ نمره");
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(-1, dp(52));
        saveLp.topMargin = dp(14);
        panel.addView(save, saveLp);
        save.setOnClickListener(v -> {
            ScoreStore.saveScore(this, LocalDate.now(), picker.getValue());
            Toast.makeText(this, "نمرهٔ امروز ذخیره شد.", Toast.LENGTH_SHORT).show();
            showScorePage();
        });
        body.addView(panel, new LinearLayout.LayoutParams(-1, -2));

        TextView footnote = text("اگر دوباره امروز نمره ثبت کنی، مقدار قبلی همان روز جایگزین می‌شود. روزهای دیگر دست‌نخورده می‌مانند.", 13, MUTED, false);
        footnote.setPadding(dp(4), dp(14), dp(4), dp(8));
        body.addView(footnote);
    }

    private void showStatsPage() {
        LinearLayout body = makePage("میانگین‌ها", "میانگین بر اساس روزهایی حساب می‌شود که نمره ثبت شده باشد.", true);
        addAverageCard(body, 7, "۷ روز اخیر");
        addAverageCard(body, 30, "۳۰ روز اخیر");
        addAverageCard(body, 365, "۳۶۵ روز اخیر");
        TextView note = text("روزهای بدون نمره، صفر در نظر گرفته نمی‌شوند؛ میانگین فقط از نمره‌های ثبت‌شده در بازه محاسبه می‌شود.", 13, MUTED, false);
        note.setPadding(dp(4), dp(12), dp(4), dp(8));
        body.addView(note);
    }

    private void addAverageCard(LinearLayout parent, int days, String title) {
        ScoreStore.Average average = ScoreStore.averageForLastDays(this, days);
        LinearLayout card = vertical();
        card.setPadding(dp(17), dp(15), dp(17), dp(15));
        card.setBackground(rounded(WHITE, 19));
        card.setElevation(dp(1));
        card.addView(text(title, 16, INK, true), new LinearLayout.LayoutParams(-1, dp(30)));
        String scoreText = average.value == null ? "—" : ScoreStore.formatScore(average.value);
        TextView value = text(scoreText, 30, PRIMARY, true);
        LinearLayout.LayoutParams valueLp = new LinearLayout.LayoutParams(-1, dp(50));
        valueLp.topMargin = dp(2);
        card.addView(value, valueLp);
        String countText = average.recordedDays == 0
                ? "هنوز نمره‌ای در این بازه ثبت نشده"
                : "بر پایهٔ " + ScoreStore.toPersianDigits(String.valueOf(average.recordedDays)) +
                  " روزِ ثبت‌شده از " + ScoreStore.toPersianDigits(String.valueOf(days)) + " روز";
        card.addView(text(countText, 12, MUTED, false), new LinearLayout.LayoutParams(-1, dp(27)));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = dp(12);
        parent.addView(card, cardLp);
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(15);
        button.setTextColor(WHITE);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackground(rounded(PRIMARY, 15));
        return button;
    }

    private void chooseReminderTime() {
        int hour = ReminderScheduler.getHour(this);
        int minute = ReminderScheduler.getMinute(this);
        TimePickerDialog dialog = new TimePickerDialog(this, (view, chosenHour, chosenMinute) -> {
            ReminderScheduler.saveTime(this, chosenHour, chosenMinute);
            showHome();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !ReminderScheduler.canSchedulePrecisely(this)) {
                new AlertDialog.Builder(this)
                        .setTitle("اجازهٔ اعلان سرِ ساعت")
                        .setMessage("برای اجرای دقیق در ساعت انتخاب‌شده، دسترسی آلارم دقیق را فعال کن. بدون این دسترسی ممکن است اعلان با تأخیر برسد.")
                        .setNegativeButton("بعداً", (d, w) -> { })
                        .setPositiveButton("رفتن به تنظیمات", (d, w) -> {
                            try {
                                startActivity(ReminderScheduler.exactAlarmSettingsIntent(this));
                            } catch (Exception e) {
                                Toast.makeText(this, "تنظیمات آلارم در این دستگاه در دسترس نیست.", Toast.LENGTH_LONG).show();
                            }
                        })
                        .show();
            }
        }, hour, minute, true);
        dialog.setTitle("ساعت یادآور روزانه");
        dialog.show();
    }

    private String timeText(int hour, int minute) {
        String value = String.format(Locale.US, "%02d:%02d", hour, minute);
        return ScoreStore.toPersianDigits(value);
    }
}
