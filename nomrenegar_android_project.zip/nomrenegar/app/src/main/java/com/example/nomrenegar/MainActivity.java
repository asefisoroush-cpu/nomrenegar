package com.example.nomrenegar;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(243, 245, 247);
    private static final int WHITE = Color.WHITE;
    private static final int INK = Color.rgb(32, 43, 49);
    private static final int MUTED = Color.rgb(104, 116, 122);
    private static final int PRIMARY = Color.rgb(35, 104, 91);
    private static final int PALE = Color.rgb(229, 241, 237);
    private static final int DISABLED = Color.rgb(232, 235, 237);
    private String currentPage = "home";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        ReminderScheduler.createNotificationChannel(this);
        ReminderScheduler.schedule(this);
        showHome();

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7001);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ReminderScheduler.schedule(this);
    }

    @Override
    public void onBackPressed() {
        if (!"home".equals(currentPage)) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radiusDp));
        return shape;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        view.setTextDirection(View.TEXT_DIRECTION_RTL);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return layout;
    }

    private LinearLayout horizontal() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private LinearLayout makePage(String title, String subtitle, boolean backButton) {
        currentPage = backButton ? "subpage" : "home";
        LinearLayout root = vertical();
        root.setBackgroundColor(BG);

        LinearLayout header = vertical();
        header.setPadding(dp(20), dp(16), dp(20), dp(14));
        if (backButton) {
            TextView back = text("‹  بازگشت", 14, PRIMARY, true);
            back.setPadding(0, 0, 0, dp(10));
            back.setOnClickListener(v -> showHome());
            header.addView(back, new LinearLayout.LayoutParams(-1, dp(32)));
        }
        TextView heading = text(title, 25, INK, true);
        header.addView(heading, new LinearLayout.LayoutParams(-1, dp(40)));
        TextView sub = text(subtitle, 13, MUTED, false);
        header.addView(sub, new LinearLayout.LayoutParams(-1, dp(28)));
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        LinearLayout body = vertical();
        body.setPadding(dp(18), dp(4), dp(18), dp(26));
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        return body;
    }

    private void showHome() {
        LinearLayout body = makePage("نمره‌نگار", "ثبت روزانه و مرور روند", false);

        LinearLayout intro = vertical();
        intro.setPadding(dp(18), dp(16), dp(18), dp(16));
        intro.setBackground(rounded(PRIMARY, 22));
        TextView introTitle = text("امروز رو ثبت کن", 18, WHITE, true);
        TextView introSub = text("هر روز فقط یک نمره؛ در صورت ویرایش، مقدار همان روز عوض می‌شود.", 13, Color.rgb(230, 242, 239), false);
        intro.addView(introTitle);
        LinearLayout.LayoutParams introSubLp = new LinearLayout.LayoutParams(-1, -2);
        introSubLp.topMargin = dp(6);
        intro.addView(introSub, introSubLp);
        body.addView(intro, new LinearLayout.LayoutParams(-1, -2));

        TextView sections = text("بخش‌ها", 17, INK, true);
        LinearLayout.LayoutParams sectionTitleLp = new LinearLayout.LayoutParams(-1, dp(40));
        sectionTitleLp.topMargin = dp(12);
        body.addView(sections, sectionTitleLp);

        LinearLayout row1 = horizontal();
        row1.addView(sectionCard("ثبت نمره", "نمرهٔ امروز از ۰ تا ۱۰", "۱", true, () -> showScorePage()),
                new LinearLayout.LayoutParams(0, dp(142), 1));
        View gap1 = new View(this);
        row1.addView(gap1, new LinearLayout.LayoutParams(dp(10), 1));
        row1.addView(sectionCard("میانگین‌ها", "۷، ۳۰ و ۳۶۵ روز", "۲", true, () -> showStatsPage()),
                new LinearLayout.LayoutParams(0, dp(142), 1));
        body.addView(row1);

        LinearLayout row2 = horizontal();
        LinearLayout.LayoutParams row2lp = new LinearLayout.LayoutParams(-1, dp(142));
        row2lp.topMargin = dp(10);
        row2.addView(sectionCard("بخش سوم", "در به‌روزرسانی آینده", "۳", false,
                () -> Toast.makeText(this, "این بخش در به‌روزرسانی‌های بعدی فعال می‌شود.", Toast.LENGTH_SHORT).show()),
                new LinearLayout.LayoutParams(0, dp(142), 1));
        row2.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
        row2.addView(sectionCard("بخش چهارم", "در به‌روزرسانی آینده", "۴", false,
                () -> Toast.makeText(this, "این بخش در به‌روزرسانی‌های بعدی فعال می‌شود.", Toast.LENGTH_SHORT).show()),
                new LinearLayout.LayoutParams(0, dp(142), 1));
        body.addView(row2, row2lp);

        LinearLayout reminder = vertical();
        reminder.setPadding(dp(16), dp(14), dp(16), dp(14));
        reminder.setBackground(rounded(WHITE, 18));
        reminder.setElevation(dp(1));
        TextView reminderTitle = text("یادآور روزانه", 15, INK, true);
        TextView reminderTime = text("هر روز ساعت " + timeText(ReminderScheduler.getHour(this), ReminderScheduler.getMinute(this)), 14, PRIMARY, true);
        TextView reminderHelp = text("برای تغییر ساعت اعلان، اینجا بزن.", 12, MUTED, false);
        reminder.addView(reminderTitle);
        LinearLayout.LayoutParams timeLp = new LinearLayout.LayoutParams(-1, dp(30));
        timeLp.topMargin = dp(4);
        reminder.addView(reminderTime, timeLp);
        reminder.addView(reminderHelp);
        reminder.setOnClickListener(v -> chooseReminderTime());
        LinearLayout.LayoutParams reminderLp = new LinearLayout.LayoutParams(-1, -2);
        reminderLp.topMargin = dp(14);
        body.addView(reminder, reminderLp);

        TextView storageNote = text("اطلاعات روی همین گوشی ذخیره می‌شود.", 12, MUTED, false);
        storageNote.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, dp(40));
        noteLp.topMargin = dp(8);
        body.addView(storageNote, noteLp);
    }

    private View sectionCard(String title, String subtitle, String numeral, boolean enabled, Runnable action) {
        LinearLayout card = vertical();
        card.setPadding(dp(14), dp(13), dp(14), dp(12));
        card.setBackground(rounded(enabled ? WHITE : DISABLED, 20));
        card.setElevation(enabled ? dp(2) : 0);
        TextView number = text(numeral, 13, enabled ? PRIMARY : MUTED, true);
        number.setGravity(Gravity.CENTER);
        number.setBackground(rounded(enabled ? PALE : Color.rgb(218, 222, 224), 30));
        card.addView(number, new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView titleView = text(title, 16, enabled ? INK : MUTED, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, dp(34));
        titleLp.topMargin = dp(6);
        card.addView(titleView, titleLp);
        TextView subView = text(subtitle, 11, MUTED, false);
        card.addView(subView, new LinearLayout.LayoutParams(-1, -2));
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> action.run());
        return card;
    }

    private void showScorePage() {
        LinearLayout body = makePage("ثبت نمره", "برای هر روز یک نمره از ۰ تا ۱۰ انتخاب کن.", true);
        LocalDate today = LocalDate.now();
        Integer saved = ScoreStore.getTenths(this, today);

        LinearLayout panel = vertical();
        panel.setPadding(dp(18), dp(18), dp(18), dp(18));
        panel.setBackground(rounded(WHITE, 22));
        TextView date = text("نمرهٔ امروز", 16, INK, true);
        date.setGravity(Gravity.CENTER);
        panel.addView(date, new LinearLayout.LayoutParams(-1, dp(32)));

        TextView current = text(saved == null ? "هنوز ثبت نشده" : "نمرهٔ ذخیره‌شده: " + ScoreStore.formatScore(saved / 10.0),
                13, saved == null ? MUTED : PRIMARY, saved != null);
        current.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams currentLp = new LinearLayout.LayoutParams(-1, dp(30));
        currentLp.topMargin = dp(4);
        panel.addView(current, currentLp);

        NumberPicker picker = new NumberPicker(this);
        picker.setMinValue(0);
        picker.setMaxValue(100);
        String[] values = new String[101];
        for (int i = 0; i <= 100; i++) values[i] = ScoreStore.formatScore(i / 10.0);
        picker.setDisplayedValues(values);
        picker.setWrapSelectorWheel(false);
        picker.setValue(saved == null ? 50 : saved);
        picker.setDescendantFocusability(NumberPicker.FOCUS_AFTER_DESCENDANTS);
        LinearLayout.LayoutParams pickerLp = new LinearLayout.LayoutParams(-1, dp(190));
        pickerLp.topMargin = dp(6);
        panel.addView(picker, pickerLp);

        TextView range = text("کمترین: ۰٫۰                       بیشترین: ۱۰٫۰", 12, MUTED, false);
        range.setGravity(Gravity.CENTER);
        panel.addView(range, new LinearLayout.LayoutParams(-1, dp(28)));

        Button save = button("ذخیرهٔ نمره");
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(-1, dp(52));
        saveLp.topMargin = dp(14);
        panel.addView(save, saveLp);
        save.setOnClickListener(v -> {
            ScoreStore.saveScore(this, LocalDate.now(), picker.getValue());
            Toast.makeText(this, "نمرهٔ امروز ذخیره شد.", Toast.LENGTH_SHORT).show();
            showScorePage();
        });
        body.addView(panel, new LinearLayout.LayoutParams(-1, -2));

        TextView footnote = text("اگر دوباره امروز نمره ثبت کنی، مقدار قبلی همان روز جایگزین می‌شود. روزهای دیگر دست‌نخورده می‌مانند.", 13, MUTED, false);
        footnote.setPadding(dp(4), dp(14), dp(4), dp(8));
        body.addView(footnote);
    }

    private void showStatsPage() {
        LinearLayout body = makePage("میانگین‌ها", "میانگین بر اساس روزهایی حساب می‌شود که نمره ثبت شده باشد.", true);
        addAverageCard(body, 7, "۷ روز اخیر");
        addAverageCard(body, 30, "۳۰ روز اخیر");
        addAverageCard(body, 365, "۳۶۵ روز اخیر");
        TextView note = text("روزهای بدون نمره، صفر در نظر گرفته نمی‌شوند؛ میانگین فقط از نمره‌های ثبت‌شده در بازه محاسبه می‌شود.", 13, MUTED, false);
        note.setPadding(dp(4), dp(12), dp(4), dp(8));
        body.addView(note);
    }

    private void addAverageCard(LinearLayout parent, int days, String title) {
        ScoreStore.Average average = ScoreStore.averageForLastDays(this, days);
        LinearLayout card = vertical();
        card.setPadding(dp(17), dp(15), dp(17), dp(15));
        card.setBackground(rounded(WHITE, 19));
        card.setElevation(dp(1));
        card.addView(text(title, 16, INK, true), new LinearLayout.LayoutParams(-1, dp(30)));
        String scoreText = average.value == null ? "—" : ScoreStore.formatScore(average.value);
        TextView value = text(scoreText, 30, PRIMARY, true);
        LinearLayout.LayoutParams valueLp = new LinearLayout.LayoutParams(-1, dp(50));
        valueLp.topMargin = dp(2);
        card.addView(value, valueLp);
        String countText = average.recordedDays == 0
                ? "هنوز نمره‌ای در این بازه ثبت نشده"
                : "بر پایهٔ " + ScoreStore.toPersianDigits(String.valueOf(average.recordedDays)) +
                  " روزِ ثبت‌شده از " + ScoreStore.toPersianDigits(String.valueOf(days)) + " روز";
        card.addView(text(countText, 12, MUTED, false), new LinearLayout.LayoutParams(-1, dp(27)));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = dp(12);
        parent.addView(card, cardLp);
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(15);
        button.setTextColor(WHITE);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackground(rounded(PRIMARY, 15));
        return button;
    }

    private void chooseReminderTime() {
        int hour = ReminderScheduler.getHour(this);
        int minute = ReminderScheduler.getMinute(this);
        TimePickerDialog dialog = new TimePickerDialog(this, (view, chosenHour, chosenMinute) -> {
            ReminderScheduler.saveTime(this, chosenHour, chosenMinute);
            showHome();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !ReminderScheduler.canSchedulePrecisely(this)) {
                new AlertDialog.Builder(this)
                        .setTitle("اجازهٔ اعلان سرِ ساعت")
                        .setMessage("برای اجرای دقیق در ساعت انتخاب‌شده، دسترسی آلارم دقیق را فعال کن. بدون این دسترسی ممکن است اعلان با تأخیر برسد.")
                        .setNegativeButton("بعداً", (d, w) -> { })
                        .setPositiveButton("رفتن به تنظیمات", (d, w) -> {
                            try {
                                startActivity(ReminderScheduler.exactAlarmSettingsIntent(this));
                            } catch (Exception e) {
                                Toast.makeText(this, "تنظیمات آلارم در این دستگاه در دسترس نیست.", Toast.LENGTH_LONG).show();
                            }
                        })
                        .show();
            }
        }, hour, minute, true);
        dialog.setTitle("ساعت یادآور روزانه");
        dialog.show();
    }

    private String timeText(int hour, int minute) {
        String value = String.format(Locale.US, "%02d:%02d", hour, minute);
        return ScoreStore.toPersianDigits(value);
    }
}
