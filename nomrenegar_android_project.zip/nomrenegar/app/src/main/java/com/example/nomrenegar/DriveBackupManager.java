package com.example.nomrenegar;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** Google-account OAuth token + Drive appDataFolder REST API helper. */
public final class DriveBackupManager {
    public static final int AUTH_REQUEST_CODE = 8110;
    private static final String TAG="NomreNegarDrive";
    private static final String PREFS="drive_settings";
    private static final String KEY_ACCOUNT="account_email";
    private static final String KEY_PENDING="pending_account";
    private static final String KEY_AUTO="auto_backup";
    private static final String SCOPE="https://www.googleapis.com/auth/drive.appdata";
    private static final ExecutorService EXEC=Executors.newSingleThreadExecutor();
    private DriveBackupManager(){}

    public static String account(Context c){return c.getSharedPreferences(PREFS,0).getString(KEY_ACCOUNT,null);}
    public static String pendingAccount(Context c){return c.getSharedPreferences(PREFS,0).getString(KEY_PENDING,null);}
    public static void clearPending(Context c){c.getSharedPreferences(PREFS,0).edit().remove(KEY_PENDING).apply();}
    public static boolean connected(Context c){return account(c)!=null;}
    public static boolean autoEnabled(Context c){return c.getSharedPreferences(PREFS,0).getBoolean(KEY_AUTO,false);}
    public static void setAutoEnabled(Context c,boolean enabled){c.getSharedPreferences(PREFS,0).edit().putBoolean(KEY_AUTO,enabled).apply();}
    public static void disconnect(Context c){c.getSharedPreferences(PREFS,0).edit().remove(KEY_ACCOUNT).remove(KEY_PENDING).putBoolean(KEY_AUTO,false).apply(); cancelAuto(c);}

    public static void chooseGoogleAccount(Activity activity){
        try{
            Intent pick=AccountManager.newChooseAccountIntent(null,null,new String[]{"com.google"},false,null,null,null,null);
            activity.startActivityForResult(pick,AUTH_REQUEST_CODE);
        }catch(Exception e){Log.e(TAG,"Cannot open account picker",e);}
    }

    public static void connect(Activity activity,String email,Consumer<Boolean> callback){
        if(email==null||email.trim().isEmpty()){callback.accept(false);return;}
        activity.getSharedPreferences(PREFS,0).edit().putString(KEY_PENDING,email).apply();
        Account account=new Account(email,"com.google");
        AccountManager.get(activity).getAuthToken(account,"oauth2:"+SCOPE,null,activity,new AccountManagerCallback<Bundle>(){
            @Override public void run(AccountManagerFuture<Bundle> future){
                try{
                    Bundle b=future.getResult();
                    String token=b.getString(AccountManager.KEY_AUTHTOKEN);
                    if(token!=null){activity.getSharedPreferences(PREFS,0).edit().putString(KEY_ACCOUNT,email).remove(KEY_PENDING).apply(); callback.accept(true); return;}
                    Intent auth=b.getParcelable(AccountManager.KEY_INTENT);
                    if(auth!=null){activity.runOnUiThread(()->activity.startActivityForResult(auth,AUTH_REQUEST_CODE));callback.accept(false);return;}
                    callback.accept(false);
                }catch(Exception e){Log.e(TAG,"Google Drive authorization failed",e);callback.accept(false);}
            }
        },new Handler(Looper.getMainLooper()));
    }

    public static void handleAuthResult(Activity activity,Intent data,Consumer<Boolean> callback){
        String email=data==null?null:data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
        if(email==null) email=activity.getSharedPreferences(PREFS,0).getString(KEY_PENDING,null);
        if(email==null){callback.accept(false);return;} connect(activity,email,callback);
    }

    public static void scheduleAuto(Context context){
        if(!autoEnabled(context)||!connected(context)){cancelAuto(context);return;}
        androidx.work.Constraints constraints=new androidx.work.Constraints.Builder().setRequiredNetworkType(androidx.work.NetworkType.CONNECTED).build();
        androidx.work.PeriodicWorkRequest request=new androidx.work.PeriodicWorkRequest.Builder(AutoBackupWorker.class,24,java.util.concurrent.TimeUnit.HOURS).setConstraints(constraints).build();
        androidx.work.WorkManager.getInstance(context).enqueueUniquePeriodicWork("nomrenegar_daily_drive_backup",androidx.work.ExistingPeriodicWorkPolicy.UPDATE,request);
    }
    public static void cancelAuto(Context context){androidx.work.WorkManager.getInstance(context).cancelUniqueWork("nomrenegar_daily_drive_backup");}
    public static void runBackupNow(Context c){String account=account(c);if(account==null)return;EXEC.execute(()->{try{uploadAuto(c,account);}catch(Exception e){Log.e(TAG,"Manual auto-backup failed",e);}});}

    static void uploadAuto(Context context,String email) throws Exception{
        Account selected=new Account(email,"com.google");
        String token=AccountManager.get(context).blockingGetAuthToken(selected,"oauth2:"+SCOPE,true);
        if(token==null||token.isEmpty())throw new IllegalStateException("Google authorization token unavailable");
        byte[] json=ScoreStore.exportJson(context).toString().getBytes(StandardCharsets.UTF_8);
        String id=findBackupFile(token);
        if(id==null)createBackupFile(token,json);else updateBackupFile(token,id,json);
    }

    private static String findBackupFile(String token)throws Exception{
        String url="https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name%3D%27nomrenegar-auto.json%27%20and%20trashed%3Dfalse&fields=files(id,name)&pageSize=10";
        JSONObject data=new JSONObject(new String(request("GET",url,token,null,"application/json"),StandardCharsets.UTF_8));
        JSONArray files=data.optJSONArray("files");if(files==null||files.length()==0)return null;return files.getJSONObject(0).getString("id");
    }
    private static void createBackupFile(String token,byte[] bytes)throws Exception{
        String boundary="nrBoundary"+Long.toHexString(System.nanoTime());
        String metadata="{\"name\":\"nomrenegar-auto.json\",\"parents\":[\"appDataFolder\"],\"mimeType\":\"application/json\"}";
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        out.write(("--"+boundary+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+metadata+"\r\n--"+boundary+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n").getBytes(StandardCharsets.UTF_8));out.write(bytes);out.write(("\r\n--"+boundary+"--").getBytes(StandardCharsets.UTF_8));
        request("POST","https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id",token,out.toByteArray(),"multipart/related; boundary="+boundary);
    }
    private static void updateBackupFile(String token,String id,byte[] bytes)throws Exception{
        request("PATCH","https://www.googleapis.com/upload/drive/v3/files/"+id+"?uploadType=media",token,bytes,"application/json; charset=UTF-8");
    }
    private static byte[] request(String method,String url,String token,byte[] body,String contentType)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod(method);c.setConnectTimeout(20000);c.setReadTimeout(20000);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Accept","application/json");
        if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type",contentType);c.setFixedLengthStreamingMode(body.length);try(OutputStream out=c.getOutputStream()){out.write(body);}}
        int status=c.getResponseCode();java.io.InputStream in=(status>=200&&status<300)?c.getInputStream():c.getErrorStream();byte[] response=new byte[0];if(in!=null){try(java.io.ByteArrayOutputStream b=new java.io.ByteArrayOutputStream()){byte[] chunk=new byte[4096];int n;while((n=in.read(chunk))!=-1)b.write(chunk,0,n);response=b.toByteArray();}}
        c.disconnect();if(status<200||status>=300)throw new java.io.IOException("Drive API HTTP "+status+": "+new String(response,StandardCharsets.UTF_8));return response;
    }
}
