package com.example.nomrenegar;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.widget.Toast;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.SecretKey;
import java.io.*;
import java.security.SecureRandom;
import java.util.*;
import org.json.JSONObject;
import org.json.JSONArray;

public final class BackupManager {
 public static final int EXPORT_REQ=8110, IMPORT_REQ=8111;
 private static String pendingPassword;
 private BackupManager(){}
 public static void export(Activity a,String password){
  try{
   JSONObject data=new JSONObject(); data.put("app","nomrenegar"); data.put("version",1);
   android.content.SharedPreferences p=a.getSharedPreferences("daily_scores_v1",0);
   JSONObject scores=new JSONObject(); for(Map.Entry<String,?> e:p.getAll().entrySet()) if(e.getValue() instanceof Integer) scores.put(e.getKey(),e.getValue());
   data.put("scores",scores);
   byte[] salt=new byte[16],iv=new byte[12]; SecureRandom r=new SecureRandom();r.nextBytes(salt);r.nextBytes(iv);
   SecretKey key=derive(password,salt);
   Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key,new GCMParameterSpec(128,iv));
   byte[] encrypted=c.doFinal(data.toString().getBytes("UTF-8"));
   ByteArrayOutputStream out=new ByteArrayOutputStream();out.write("NOMREN1".getBytes("UTF-8"));out.write(salt);out.write(iv);out.write(encrypted);
   pendingPassword=password;
   Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_TITLE,"Nomrenegar-backup.nrb");a.startActivityForResult(i,EXPORT_REQ);
   cache=out.toByteArray();
  }catch(Exception e){Toast.makeText(a,"ساخت پشتیبان ناموفق بود: "+e.getMessage(),Toast.LENGTH_LONG).show();}
 }
 private static byte[] cache;
 public static void handleResult(Activity a,int request,int result,Intent data){
  if(result!=Activity.RESULT_OK||data==null||data.getData()==null)return;
  Uri uri=data.getData();
  try{
   if(request==EXPORT_REQ&&cache!=null){OutputStream o=a.getContentResolver().openOutputStream(uri);o.write(cache);o.close();cache=null;Toast.makeText(a,"فایل پشتیبان رمزگذاری‌شده ذخیره شد.",Toast.LENGTH_LONG).show();}
   else if(request==IMPORT_REQ){
    InputStream in=a.getContentResolver().openInputStream(uri);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)b.write(buf,0,n);in.close();
    byte[] raw=b.toByteArray();if(raw.length<35||!new String(raw,0,7,"UTF-8").equals("NOMREN1"))throw new Exception("فرمت فایل معتبر نیست");
    byte[] salt=Arrays.copyOfRange(raw,7,23),iv=Arrays.copyOfRange(raw,23,35),enc=Arrays.copyOfRange(raw,35,raw.length);
    Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,derive(pendingPassword,salt),new GCMParameterSpec(128,iv));
    JSONObject obj=new JSONObject(new String(c.doFinal(enc),"UTF-8"));if(!"nomrenegar".equals(obj.optString("app")))throw new Exception("این فایل پشتیبان نمره‌نگار نیست");
    JSONObject scores=obj.getJSONObject("scores");android.content.SharedPreferences.Editor ed=a.getSharedPreferences("daily_scores_v1",0).edit();ed.clear();Iterator<String> it=scores.keys();while(it.hasNext()){String k=it.next();ed.putInt(k,scores.getInt(k));}ed.apply();
    Toast.makeText(a,"پشتیبان با موفقیت بازیابی شد.",Toast.LENGTH_LONG).show();
   }
  }catch(Exception e){Toast.makeText(a,"باز کردن فایل ناموفق بود؛ رمز یا فایل را بررسی کن.",Toast.LENGTH_LONG).show();}
 }
 public static void importFile(Activity a,String password){pendingPassword=password;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");a.startActivityForResult(i,IMPORT_REQ);}
 private static SecretKey derive(String password,byte[] salt)throws Exception{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(new PBEKeySpec(password.toCharArray(),salt,120000,256)).getSecret();}
}