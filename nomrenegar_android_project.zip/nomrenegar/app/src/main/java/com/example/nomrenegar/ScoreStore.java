package com.example.nomrenegar;

import android.content.Context;
import android.content.SharedPreferences;

import java.time.LocalDate;
import java.util.Locale;

/** Persistent local storage. Scores are saved as tenths (0..100) to avoid float rounding. */
public final class ScoreStore {
    private static final String PREFS = "daily_scores_v1";
    private static final String PREFIX = "score_";

    private ScoreStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String key(LocalDate date) {
        return PREFIX + date.toString();
    }

    public static boolean hasScore(Context context, LocalDate date) {
        return prefs(context).contains(key(date));
    }

    public static Integer getTenths(Context context, LocalDate date) {
        SharedPreferences p = prefs(context);
        String k = key(date);
        return p.contains(k) ? p.getInt(k, 0) : null;
    }

    /** Saving again on the same date replaces that date's value. */
    public static void saveScore(Context context, LocalDate date, int tenths) {
        int safeValue = Math.max(0, Math.min(100, tenths));
        prefs(context).edit().putInt(key(date), safeValue).apply();
    }

    public static Average averageForLastDays(Context context, int dayCount) {
        LocalDate today = LocalDate.now();
        int sumTenths = 0;
        int count = 0;
        for (int offset = 0; offset < dayCount; offset++) {
            Integer value = getTenths(context, today.minusDays(offset));
            if (value != null) {
                sumTenths += value;
                count++;
            }
        }
        return new Average(count == 0 ? null : (sumTenths / 10.0) / count, count, dayCount);
    }

    public static String formatScore(double score) {
        return toPersianDigits(String.format(Locale.US, "%.1f", score)).replace('.', '٫');
    }

    public static String toPersianDigits(String value) {
        String western = "0123456789";
        String persian = "۰۱۲۳۴۵۶۷۸۹";
        StringBuilder out = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char ch = value.charAt(i);
            int index = western.indexOf(ch);
            out.append(index >= 0 ? persian.charAt(index) : ch);
        }
        return out.toString();
    }

    public static final class Average {
        public final Double value;
        public final int recordedDays;
        public final int totalDays;

        private Average(Double value, int recordedDays, int totalDays) {
            this.value = value;
            this.recordedDays = recordedDays;
            this.totalDays = totalDays;
        }
    }
}
