package com.example.nomrenegar;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONException;
import org.json.JSONObject;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Stores one score per ISO-8601 Gregorian date. Scores are stored as tenths (0..100). */
public final class ScoreStore {
    private static final String PREFS = "daily_scores_v1";
    private static final String PREFIX = "score_";
    private ScoreStore() {}
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    private static String key(LocalDate date) { return PREFIX + date; }
    public static boolean hasScore(Context c, LocalDate d) { return prefs(c).contains(key(d)); }
    public static Integer getTenths(Context c, LocalDate d) { SharedPreferences p=prefs(c); String k=key(d); return p.contains(k)?p.getInt(k,0):null; }
    public static void saveScore(Context c, LocalDate d, int tenths) { prefs(c).edit().putInt(key(d),Math.max(0,Math.min(100,tenths))).apply(); }

    public static Map<LocalDate,Integer> getAllScores(Context c) {
        Map<LocalDate,Integer> result=new LinkedHashMap<>();
        for(Map.Entry<String,?> e:prefs(c).getAll().entrySet()) {
            if(e.getKey().startsWith(PREFIX) && e.getValue() instanceof Integer) {
                try { LocalDate d=LocalDate.parse(e.getKey().substring(PREFIX.length())); int v=(Integer)e.getValue(); if(v>=0&&v<=100) result.put(d,v); }
                catch(Exception ignored) { }
            }
        }
        return result;
    }

    public static JSONObject exportJson(Context c) throws JSONException {
        JSONObject data=new JSONObject(); data.put("format","nomrenegar-backup-v1");
        JSONObject scores=new JSONObject();
        for(Map.Entry<LocalDate,Integer> e:getAllScores(c).entrySet()) scores.put(e.getKey().toString(),e.getValue());
        data.put("scores",scores); return data;
    }

    /** Validates every record before changing storage; imported dates replace matching dates. */
    public static void importJson(Context c, JSONObject data) throws JSONException {
        if(!"nomrenegar-backup-v1".equals(data.optString("format"))) throw new JSONException("قالب فایل پشتیبان معتبر نیست.");
        JSONObject scores=data.getJSONObject("scores");
        Map<String,Integer> validated=new LinkedHashMap<>();
        java.util.Iterator<String> keys=scores.keys();
        while(keys.hasNext()) {
            String date=keys.next();
            try { LocalDate.parse(date); } catch(Exception ex) { throw new JSONException("تاریخ داخل فایل معتبر نیست."); }
            int value=scores.getInt(date); if(value<0||value>100) throw new JSONException("نمره خارج از محدوده است.");
            validated.put(PREFIX+date,value);
        }
        SharedPreferences.Editor editor=prefs(c).edit(); for(Map.Entry<String,Integer> e:validated.entrySet()) editor.putInt(e.getKey(),e.getValue()); editor.apply();
    }

    public static Average averageForLastDays(Context c,int dayCount) { LocalDate end=LocalDate.now(); return averageForRange(c,end.minusDays(dayCount-1L),end,dayCount); }
    public static Average averageForRange(Context c,LocalDate start,LocalDate end,int totalDays) {
        int sum=0,count=0;
        for(Map.Entry<LocalDate,Integer> e:getAllScores(c).entrySet()) if(!e.getKey().isBefore(start)&&!e.getKey().isAfter(end)){sum+=e.getValue();count++;}
        return new Average(count==0?null:(sum/10.0)/count,count,totalDays);
    }
    public static String formatScore(double score) { return toPersianDigits(String.format(Locale.US,"%.1f",score)).replace('.', '٫'); }
    public static String toPersianDigits(String value) {
        String western="0123456789",persian="۰۱۲۳۴۵۶۷۸۹"; StringBuilder out=new StringBuilder(value.length());
        for(int i=0;i<value.length();i++){char ch=value.charAt(i);int index=western.indexOf(ch);out.append(index>=0?persian.charAt(index):ch);} return out.toString();
    }
    public static final class Average {
        public final Double value; public final int recordedDays,totalDays;
        private Average(Double v,int recorded,int total){value=v;recordedDays=recorded;totalDays=total;}
    }
}
